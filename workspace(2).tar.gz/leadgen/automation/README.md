# Self-running radar (GitHub Actions, free)
1. Create a **private** GitHub repo (free), e.g. `cos-radar`.
2. Copy this whole `leadgen/` folder into the repo root (keep paths: `leadgen/scripts`, `leadgen/automation`).
3. Repo → Settings → Secrets and variables → Actions → New repository secret (only what you have):
   - `ZEROBOUNCE_API_KEY` (optional — verifies 25 emails/run; re-run daily via workflow_dispatch to clear backlog)
   - `TELEGRAM_BOT_TOKEN` + `TELEGRAM_CHAT_ID` (optional push alerts — create bot via @BotFather, get chat id via @userinfobot)
   - `ADZUNA_APP_ID` / `ADZUNA_API_KEY`, `JOOBLE_API_KEY` (optional — 12_job_feeds.py picks them up automatically; free at developer.adzuna.com and jooble.org/api/about)
4. Actions tab → enable. Runs Mondays 07:00 UTC; "Run workflow" button = manual run.
5. Results are committed back to `leadgen/results/` — pull or view in the repo.
Notes: Actions runners reach web.archive.org + remoteok/themuse fine (sandbox here couldn't). Never commit API keys as files — secrets only.
