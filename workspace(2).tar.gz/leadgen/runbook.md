# RUNBOOK — Re-runnable Founder/CEO/MD Lead Pipeline ($0 stack)

Everything lives in `leadgen/`. Re-run top-to-bottom in ~10 minutes of machine time per 100–150 contacts.

## 0. File map
```
leadgen/
├── scripts/
│   ├── yc_parse.py               # page → structured JSON extractor
│   ├── 01_discover.py            # YC sitemap crawl + your boolean filters  (parameterized)
│   ├── 02_select.py              # 1 best person/company, global round-robin
│   ├── 03_websites.py            # robots-compliant site crawl: emails/phones/LinkedIn
│   ├── 04_github_mx.py           # GitHub commit emails + pattern detection + MX checks
│   ├── 05_linkedin_ctx.py        # attribute site LinkedIn links to the founder by name context
│   ├── 06_assemble.py            # waterfall, scoring, dedupe, compliance flags → CSV/XLSX
│   └── 07_enrich_with_keys.py    # OPTIONAL freemium upgrade (ZeroBounce/Hunter/Apollo keys)
├── data/                          # raw + intermediate (audit trail: keep it)
├── out/contacts.csv|.xlsx         # deliverable schema (18 columns)
├── results/suppression_list.csv       # opt-outs & dead emails — ALWAYS check before sending
├── report.md                      # pilot report
└── logs/                          # run + enrichment logs
```

## 1. Re-run with NEW keywords (your exact use case)
Filters are CLI flags on step 01. Defaults reproduce your original boolean search:
```bash
cd leadgen && python3 scripts/01_discover.py \
  --include '\b(founder|co-?founder|ceo|chief executive|managing director)\b' \
  --exclude '(freelance|stealth|self[\s-]?employ|part[\s-]?time|independent)' \
  --target 140 --max-fetch 650 --seed 42
```
Examples:
- COO/Chief-of-Staff-friendly ops leaders: `--include '\b(coo|chief operating|head of operations|chief of staff)\b'`
- Agency MDs (needs non-YC source, see §7) or a fresh slice: `--seed 7 --target 300`
Then run the rest unchanged:
```bash
python3 scripts/02_select.py && python3 scripts/03_websites.py && python3 scripts/04_github_mx.py \
 && python3 scripts/05_linkedin_ctx.py && python3 scripts/06_assemble.py
```
Outputs land in `results/`. `02_select.py` TARGET is edited at the top (default 105 people).

## 2. Hard rules baked in (do not remove)
- robots.txt is fetched & honored per site (`03_websites.py`); YC filtered-search URL `/companies?*` is never requested (disallowed) — only sitemap + individual pages.
- No LinkedIn access. Personal LinkedIn URLs come only from company-owned pages (name-context matched) or the licensed search API.
- Inference is always labeled `unverified - inferred (…)`. Domains with **no MX** get NO email (prevents guaranteed bounces).
- Everything is business-contact data; logs keep the audit trail.

## 3. Schema (one row per person)
Full name | Title | Company | Company domain | Headcount band | Industry | Country/City | LinkedIn URL | Work email | Email status | Email source | Phone | Phone type | Phone source | Other channels | Confidence | Date collected | Notes (compliance flag + YC batch + caveats)

## 4. FREE verification upgrade (recommended first move, ~10 min setup)
1. **ZeroBounce** — zerobounce.net → Sign Up (free) → 100 validations/month → API Key from dashboard. ⚠️ Field-tested 2026-10-01: a fresh account can return "ran out of credits" after only a few validations — open the dashboard, confirm the signup email, and check the credit balance before batch runs.
2. **Hunter.io** — requires a professional email at signup (skip if you don't have one; ZeroBounce covers verification).
3. (Optional) **GitHub token** — github.com → Settings → Developer settings → Personal access token (fine-grained, public repos read-only) → `export GITHUB_TOKEN=…` (raises API 60/hr → 5,000/hr, so `04_github_mx.py` can cover every org).
4. Run:
```bash
export ZEROBOUNCE_API_KEY=zb_xxx
python3 scripts/07_enrich_with_keys.py --zerobounce 100 --hunter 0 --apollo 0
```
**Idempotent:** rows that already carry a verdict (`verified*`/`DEAD`/`risky`) are skipped on re-runs — only pending rows spend credits. Effect: `Email status` becomes `verified (…)` / `verified* (catch-all)` / `risky` / `DEAD - do not use`; DEAD emails are removed from the outreach column, auto-appended to `suppression_list.csv`, and get untested fallback patterns in Notes. Then `python3 scripts/08_finalize.py` rebuilds `results/contacts_enriched.csv|.xlsx` (with a Verification-log tab). Free credits reset monthly → re-run to clear the backlog.

## 5. FREE scaling of phones & LinkedIn
- **Apollo.io (free plan):** ⚠️ Field-tested 2026-10-01: the **API is NOT included in the Free plan** (403 `API_INACCESSIBLE` on `people/match`) — automation with an Apollo key requires a paid plan. The **web UI is free** and works manually. Verified free-plan economics (2026): **900 credits/year** per seat (1 credit per email/phone reveal) when signed up with a personal email; the 10k-email-credit regime requires a verified corporate domain; ~5 mobile credits/month; only a few CSV exports/month (do one big export, not many small). Walkthrough: **Search → People → Job Titles (toggle = Current):** Founder, Co-founder, CEO, Chief Executive Officer, Managing Director → same filter's **Exclude** field: Freelance, Self-Employed, Independent, Part Time, Stealth → **# Employees:** 11–50, 51–200, 201–500 → geography empty (global). Harvest **LinkedIn URLs free** from person cards (0 credits); spend reveals only on priority targets (band 51–500 + CEO titles). **Save search** for new-match alerts. Skip Sequences (2 max on free; send 1:1 from personal Gmail for job outreach anyway) and the LinkedIn extension overlay (operates on logged-in LinkedIn — excluded by hard rules). Export CSV → drop into workspace → merge/dedupe/suppression-check against `results/contacts_enriched.xlsx`.
- **Lusha (free):** 40–70 credits/month, Chrome extension — spot-look up your top 20 targets for direct phones.
- **Ask me:** I can run more licensed-search batches (like the 8 in this pilot) to lift personal-LinkedIn coverage for any subset — just name the rows.

## 6. Confidence scoring (how to read the list)
- **high** — email actually published (company site/GitHub commit) attributed to the person by name match, or provider-verified.
- **medium** — email inferred from a *real* pattern observed at that exact domain (team commits/staff emails), or convention-inferred **plus** ≥1 other live channel (phone/LinkedIn/reachable site).
- **low** — convention-inferred only (MX exists, pattern unknown) or sparse data. Verify before sending.
Always cross-check `results/suppression_list.csv` before any campaign.

## 7. Swapping/expanding company sources (for non-tech "Managing Director" targets)
| Source | Free access | What it gives | Caveat |
|---|---|---|---|
| YC directory (current) | sitemap + pages | exact headcount, founders, links | startup/tech skew |
| Companies House (UK) | free API key | directors + officer names, active status | no headcount/emails |
| OpenCorporates | free API tier | registry data, some officer names | no emails |
| Clutch.co / Sortlist | public listing pages | agency size bands, leadership sometimes | check robots per page |
| Welcome to the Jungle | public company pages | headcount bands, team articles | HTML varies |
| Conference speaker lists / podcasts | public pages | name+title+often email | manual-ish; good for MDs |
Pattern: write a small `01b_discover_<source>.py` that emits the same JSONL shape as `companies_matched.jsonl` (`name, slug, website, band, country, city, tags, matched_founders[full_name,title,is_active]`) — steps 02–07 then work unchanged.

## 8. Outreach compliance cheat-sheet (job-search context)
- **GDPR/UK (flagged rows):** 1:1 personalized job-application messages; identify yourself + purpose; process minimal data; honor opt-outs (→ suppression list); legitimate-interest basis is appropriate for unsolicited job applications to business contacts.
- **Canada (CASL rows):** a genuine personal job application isn't commercial marketing, but keep it 1:1, truthful, with your contact info; never buy/send lists.
- **US (CAN-SPAM/TCPA):** non-misleading subject, real identity, working reply address; **calls:** business lines from company sites only, no autodialer, respect DNC for mobiles.
- Cadence that won't torch your domain: <30 new cold emails/day from personal Gmail, spaced, individualized; log every opt-out same-day.

## 9. Monthly maintenance loop
1. Re-run §1 with a new `--seed` for fresh companies. 2. Re-run §4 when free credits reset (verify the low-confidence backlog). 3. Re-check titles of anyone you haven't contacted yet (people move). 4. Prune/append `suppression_list.csv`. 5. Archive `results/` with date suffix before overwriting.

## 10. Hiring-signal radar (the conversion layer) — re-run WEEKLY
```bash
python3 scripts/09_hiring_signals.py   # ATS public APIs (Greenhouse/Lever/Ashby/BambooHR) + HN Who's Hiring
python3 scripts/09b_radar_v2.py        # + Personio/Recruitee/SmartRecruiters/Breezy/Teamtailor/JazzHR/Workable, careers-page provider detection
python3 scripts/12_job_feeds.py        # CoS job-feed monitor (Remotive/Himalayas/WorkingNomads/HN; Adzuna+Jooble if env keys) -> results/cos_job_feed.csv + new_p0_candidates.csv
python3 scripts/13_edgar_discovery.py  # reverse discovery: all SEC Form D filers last week -> funded_leads.csv (fund classifier + YC match + SEC officer names)
python3 scripts/14_wayback_mining.py   # archived-page email recovery for email-gap rows (run in GH Actions; sandbox can't reach archive.org)
python3 scripts/11_edgar_triggers.py   # forward trigger: Form D recency flags on existing US rows
python3 scripts/10_action_plan.py      # re-tier P0-P3 + rebuild results/contacts_enriched.xlsx + hot_targets.csv
```
- **P0** = live CoS/Founder's-Office/BizOps/EA-to-founder req → dual-track (apply + founder email) within 48h.
- **P1** = ops/strategy reqs only → create-the-role pitch. **P2** = open board, no match → monitor. **P3** = no signal.
- All scripts idempotent. Playbook/templates/cadence: `outreach_kit.md`.
- Extending coverage: for ATSs without public APIs (Workday, Hibob…), check the `careers_pages` links in `data/hiring_signals.json` manually (~2 min/company).

## 11. Fully-automated mode (GitHub Actions, $0)
Copy `leadgen/` into a private GitHub repo and follow `automation/README.md` — the whole radar (09→09b→12→13→14→10, optional ZeroBounce 25/day, optional Telegram push) runs every Monday 07:00 UTC and commits fresh results back to the repo. Secrets only; keys never in files.

## 12. Free-tier ledger (verified 2026-10-01/02)
| Service | Free allowance | Used for |
|---|---|---|
| Verifalia | 25 validations/DAY (~750/mo) | primary email verification backlog (sign up → API key → set env `VERIFALIA_*` or use dashboard) |
| ZeroBounce | 100/mo (check dashboard activation) | verification (script 07) |
| MillionVerifier | 100 one-time trial | overflow verification |
| Adzuna API | 2,500 calls/mo | CoS job-feed monitor (script 12) |
| Jooble API | free key | job-feed monitor (script 12) |
| GitHub API | 60/hr anon, 5k/hr with free token | commit-email patterns (script 04) |
| SEC EDGAR | unlimited (fair access, UA header) | funding triggers (11) + reverse discovery (13) |
| Remotive / Himalayas / Working Nomads / HN Algolia | no key | job feeds (12) |
| Lusha / Kaspr / SignalHire extensions | 40–70 / small monthly | manual phone top-ups for final-round targets |
Refused on principle: LinkedIn scrapers/Apify actors, breach-DB checks, unofficial Indeed endpoints, Oracle-free-tier SMTP (port 25 blocked by policy).
