# Lead-Gen Pilot Report — Founder/CEO/MD Contacts (for Founder's Office / CoS job search)

**Run date:** 2026-10-01 · **Cost:** $0.00 · **Operator:** autonomous pipeline (this workspace) · **Deliverable:** `leadgen/results/contacts.xlsx` (+ `contacts.csv`)

---

## 1. Parameters used (from your Step-0 answers)

| Parameter | Value |
|---|---|
| Geography | Global (no restriction); EU/UK/CA/CH rows flagged for GDPR/CASL/FADP |
| Target | Current Founder / Co-founder / CEO / Managing Director — i.e., the people who *hire* a Chief of Staff / Founder's Office lead |
| Company size | 11–50, 51–200, 201–500 employees (exact bands) |
| Industry | Any (source skews startup/tech — see Gaps) |
| Volume | 104 test contacts (you asked 50–100; pipeline scales, see Runbook) |
| Budget | $0 — public sources + freemium only |
| Use | Personal job-search outreach (email, phone, LinkedIn) |
| Exclusions | freelance, stealth, self-employed, part time, independent (post-filter on title/headline/bio); non-current roles; non-operating companies |

## 2. Stack chosen & why (≤10 lines)

1. **$0 + no keys rules out** ZoomInfo/Cognism/PDL/RocketReach (paid), and Clay's usable tiers (~$149+/mo).
2. **Company+people discovery: Y Combinator public directory** — official sitemap (6,382 company URLs, published *for* crawlers) → individual company pages (allowed by robots.txt; only the filtered search URL `/companies?*` is disallowed and was never touched). Pages embed structured JSON: exact `team_size`, `ycdc_status: Active`, founder names/titles, website, GitHub, company LinkedIn. Best free fit for CoS-target companies; global; auditable.
3. **Enrichment waterfall (all free):** company websites (robots.txt-checked crawl of home/contact/about/imprint) → email+phone mining → name-pattern attribution → GitHub commit author emails (public API, 56 calls, pattern detection) → DNS MX validation (dnspython) → pattern/convention inference, **every inferred value labeled unverified**.
4. **Verification:** real SMTP impossible here (sandbox blocks port 25) → key-ready upgrade script uses **ZeroBounce (100 free validations/mo)** + **Hunter (~50 free credits/mo)**; statuses then become `verified`/`risky`/`DEAD`.
5. **Personal LinkedIn:** only from company-owned pages (name-context matched) and a **licensed search API** (8 targeted queries). No LinkedIn scraping, no logins, no fake accounts — per your hard rules.
6. **Orchestration:** pure Python (`leadgen/scripts/01–07`), logged, re-runnable, parameterized — no n8n/Make needed at this scale.

## 3. Results

**104 contacts · 25 countries · 3 headcount bands**

| Metric | Value | Notes |
|---|---|---|
| Companies discovered (matching all filters) | 140 of 588 YC pages fetched (24% hit rate) | from 6,382-company sitemap pool |
| People selected | 105 → **104 rows** | 1 excluded: founder left company Sep 2023 (stale source data caught by recency check) |
| Headcount bands | 11–50: 64 · 51–200: 36 · 201–500: 4 | exact bands, from directory `team_size` |
| Countries | US 42, IN 12, CA 6, SG 5, MX 4, FR 3, CO 3, BR 3, IL 3, CH 2, GB 2, DE 2, +13 more | global as requested |
| **Email coverage** | **97/104 = 93.3%** | 2 found published on company sites · 14 inferred from *real team-email patterns* (GitHub commits / on-site staff emails) · 81 inferred from band convention (all marked `unverified`) · 7 intentionally blank (domain has **no MX records** — inferring would guarantee bounces) |
| **Phone coverage** | **23/104 = 22.1%** | 16 main lines, 4 mobiles, 3 toll-free — all published on company websites; junk regex hits auto-filtered |
| Personal LinkedIn | 17/104 = 16.3% | company LinkedIn page: 85/104 = 81.7% (in Other channels) |
| Other channels | role emails (hello@/jobs@), X/Twitter, website, YC profile | in Other channels column |
| Confidence | high: 2 · medium: 39 · low: 63 | scoring rules in Runbook §6 |
| Compliance flags | 19 rows GDPR/UK-GDPR/CASL/FADP | embedded in Notes column |
| Cost | **$0** | ~1,450 HTTP requests total, all polite-throttled & robots-compliant |

**Top industries in list:** Fintech 28 · AI 24 · B2B 23 · SaaS 22 · Payments 8 · Dev Tools 8 · Health Tech 7.

### Hit rates & cost per contact (pilot economics)
- YC page → qualifying company: **24%** · qualifying company → contactable email: **93%** · → phone: **22%** · → personal LinkedIn: **16%**
- Cost per contact: **$0 cash**; ~35 min machine time; zero manual steps.
- Known deliverability expectation for the 81 convention-inferred emails: industry pattern-guess accuracy is roughly 50–75% — **verify before sending** (free route below).

## 4. Legal posture (what was and wasn't done)

- ✅ Only public pages + official sitemap + public GitHub API + licensed search API. ✅ robots.txt checked per-site before crawling subpages. ✅ No LinkedIn access/scraping, no logins, no CAPTCHA/paywall circumvention. ✅ Business contact data only. ✅ All inferred data labeled `unverified`; nothing fabricated. ✅ Suppression list initialized (`results/suppression_list.csv`); 1 recency exclusion logged in the audit tab.
- ⚠️ Outreach is **your** action from your own mailbox/phone: for the 19 GDPR/UK/CASL-flagged rows, send individualized 1:1 job-application messages (legitimate interest / personal-communication basis), identify yourself, and honor any opt-out by adding to the suppression list. For calls: business lines only, no autodialers (TCPA), check national DNC rules for mobiles.

## 5. Known gaps

1. **No SMTP-verified emails yet** (port 25 blocked in sandbox) — fixed for free via ZeroBounce/Hunter keys (`scripts/07`, Runbook §4).
2. **81 convention-inferred emails** are best-guesses with MX-confirmed domains — treat as leads, not facts.
3. **Phone/mobile coverage is low** — free providers don't expose mobiles at scale; Apollo free gives 5 mobile credits/mo, Lusha 40 credits/mo (Runbook §5).
4. **Personal LinkedIn at 16%** — Apollo free search returns LinkedIn URLs natively; or I can batch more licensed searches next turn.
5. **Source skew:** YC = startup/tech. For "Managing Director" in agencies/consulting/manufacturing, swap in Companies House (free API), OpenCorporates, Clutch, WTTJ (Runbook §7).
6. **Freshness:** directory data can lag (caught 1 stale founder, flagged 1 role change — Snapdocs). Re-verify top targets before outreach.

## 6. Recommended next steps

1. **You (10 min):** create free accounts → ZeroBounce, Hunter.io, (optional) Apollo + GitHub token. Paste keys per Runbook §4.
2. **I run** `07_enrich_with_keys.py` → up to ~125 emails become `verified`/`risky`/`DEAD`, invalids auto-suppressed; optionally Apollo fills LinkedIn + mobiles.
3. **Prioritize outreach:** `Confidence ≥ medium` **and** band `51–500` first (that's where formal CoS/Founder's-Office roles exist; 40 rows qualify now).
4. **Scale discovery:** re-run with `--target 600 --seed 7` (different slice of the 6.3k pool) or full sweep; add non-YC sources for non-tech MDs.
5. Say the word and I'll also draft the outreach templates (email/LinkedIn/call script) tailored to CoS positioning.

---

## 7. Pass 2 — Verification run (2026-10-01, user-supplied keys)

**Inputs:** ZeroBounce key ✅ working · Apollo key ❌ **API not included in Free plan** (explicit 403 `API_INACCESSIBLE` — Apollo's API requires a paid plan; the free plan still works via the web UI, see Runbook §5) · Hunter — not possible (signup requires a professional email).

**Results (6 validations before the ZeroBounce account hit "ran out of credits"):**

| Outcome | Count | Rows |
|---|---|---|
| `verified` (SMTP-valid, non-catch-all) → confidence HIGH | 1 | david.eberle@typewise.app (found on company site **and** now SMTP-verified) |
| `verified*` (valid but catch-all domain) → confidence MEDIUM, caution note | 1 | justin@prosights.co |
| `DEAD` (mailbox_not_found) → **suppressed**, email removed from outreach column, fallback patterns noted | 3 | AccioJob, Ambient.ai, Campfire — all were "real-pattern" inferences; proof that verification is mandatory |
| Pending (credits exhausted mid-batch) | 92 | statuses untouched, still honestly labeled `unverified - inferred` |

**Current list state (`results/contacts_enriched.xlsx` / `.csv`):** 104 rows · **94 usable emails** · 7 no-MX blanks · 3 suppressed · confidence high 1 / medium 37 / low 66 · phones 23 · personal LinkedIn 17.

**Why credits ran out:** the account validated only ~6 addresses before returning "Invalid API key or your account ran out of credits." Likely the signup's 100 free credits aren't active yet (check dashboard → confirm the signup email / look at the credit balance). Once the balance shows credits, re-run the exact command from Runbook §4 — the script is now **idempotent**: it skips rows that already carry a verdict, so only the 92 pending rows consume credits.

**Key hygiene:** keys were used as environment variables only; they are **not** written into any workspace file. Consider rotating the Apollo master key since it was shared in chat.

---

## 8. Pass 3 — Hiring-signal radar (2026-10-01, the conversion layer)

Scanned all 105 target companies via **official public ATS APIs** (Greenhouse boards-api, Lever postings API, Ashby posting-api, BambooHR careers JSON — all designed for public embedding; no logins, no scraping) + HN Who's Hiring via the **official Algolia API**.

**Boards found: 28/105.** Tiers (see `results/hot_targets.csv` + Action Plan tab):
- **P0 — 8 companies hiring CoS/Founder's-Office roles RIGHT NOW:** Vapi (Chief of Staff), Verse Medical (Chief of Staff), Encord (Founder's Office), Zip (Business Operations Manager), Gigs (Business Operations / Head of Operations), Stepful (EA to Founders), Twenty (Strategic Finance & BizOps Associate), Jeeves (Strategy & Ops Analyst).
- **P1 — 8 companies hiring ops/strategy but no CoS req** (create-the-role pitch): Curri, voize, Codes Health, Luminai, Jiga, Oneleet, Mundo AI, Bitmovin.
- **P2 — 41** with open boards but no matching roles (growth signal; monitor weekly). **P3 — 47** no signal.
- HN Who's Hiring (last 5 months): no genuine CoS openings this cycle; scan repeats monthly.

Playbook for every tier, templates, cadence, call scripts, one-pager structure, and volume/compliance rules: **`leadgen/outreach_kit.md`**. Re-run radar weekly: `python3 leadgen/scripts/09_hiring_signals.py && python3 leadgen/scripts/10_action_plan.py`.

---

## 9. Pass 4 — v2 research build (2026-10-02): more APIs, feeds, triggers, automation

Everything below was live-tested in the sandbox this pass (not paper research):

| Module | Status | Yield |
|---|---|---|
| **Radar v2** (`09b`) — Personio, Recruitee, SmartRecruiters, Breezy, Teamtailor, JazzHR, Workable + careers-page provider detection | ✅ ran on all 105 | +3 boards discovered; Personio feed confirmed live (voize). No new P0s — v1 caught them |
| **CoS job-feed monitor** (`12`) — Remotive, Himalayas, Working Nomads, HN Algolia | ✅ ran | 1 HOT lead: **Stpkr Technologies** (Noida, hardware wearables) — public email `arnav@stpkr.in`, explicitly open to undefined roles. RemoteOK/TheMuse 403-block datacenter IPs (work from GH Actions). Adzuna (2,500 free calls/mo) + Jooble slots coded, await free keys |
| **HN filter hardening** | ✅ | False positive caught & excluded: a job-SEEKER post — filter now separates employers from seekers |
| **Reverse EDGAR discovery** (`13`) — every SEC Form D filer, last 5 business days | ✅ ran | **890 filings parsed (~180/day)**; fund/PE/RE classifier (500 flagged non-employers); ~390 operating companies incl. FreeFall Aerospace, Axle Labs, CScale; 0 YC-matches this week (honest: single-week YC density is low — compounds as a weekly monitor) |
| **Forward EDGAR triggers** (`11`) | ✅ shipped | 9 US rows flagged "recently raised": **Vapi, Gigs, Stepful (triple-signal: raised + hiring your role + founder contact)**, Zeal, Eden, Fathom, FIRST, Hedgehog, Andson |
| **Wayback email mining** (`14`) | ⚠️ sandbox can't reach archive.org | Runs in GH Actions (workflow included); targets the 10 email-gap rows |
| **GitHub Actions pack** (`automation/`) | ✅ built | `weekly_radar.yml`: Mondays 07:00 UTC runs the full radar → commits results → optional Telegram push + optional ZeroBounce 25/day. Setup: `automation/README.md` |
| **Verification free-tier ledger** | ✅ verified online | Verifalia **25/day ≈ 750/mo** + ZeroBounce 100/mo + MillionVerifier 100 trial ≈ **850+ free verifications/mo** — clears the 92-email backlog in days |

**Workspace note:** outputs moved `out/` → `results/` (snapshot system wipes folders named `out`). Deliverables now live in `leadgen/results/`.

