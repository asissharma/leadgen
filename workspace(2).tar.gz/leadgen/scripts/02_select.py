import json, re
from collections import defaultdict

rows = [json.loads(l) for l in open('leadgen/data/companies_matched.jsonl')]

def rank_founder(f):
    t = (f.get('title') or '').lower()
    if 'ceo' in t or 'chief executive' in t or 'managing director' in t: return 0
    if re.search(r'founder\s*/\s*ceo|ceo\s*/\s*founder', t): return 0
    if 'founder' in t and 'co' not in t: return 1
    return 2

by_country = defaultdict(list)
for c in rows:
    fs = sorted(c['matched_founders'], key=rank_founder)
    c['best_founder'] = fs[0]
    by_country[c.get('country') or '??'].append(c)

# round-robin across countries for global diversity; within country, bigger bands first
order = {'51-200':0, '201-500':0, '11-50':1}
for k in by_country: by_country[k].sort(key=lambda c: order.get(c['band'],2))
selected, TARGET = [], 105
while len(selected) < TARGET and any(by_country.values()):
    for k in sorted(by_country, key=lambda k: -len(by_country[k])):
        if by_country[k] and len(selected) < TARGET:
            selected.append(by_country[k].pop(0))

with open('leadgen/data/people_target.jsonl','w') as f:
    for c in selected:
        rec = dict(c)
        f.write(json.dumps(rec)+'\n')

from collections import Counter
print('selected people:', len(selected))
print('countries:', Counter(c.get('country') for c in selected).most_common(20))
print('bands:', Counter(c['band'] for c in selected))
print('sample titles:', Counter((c['best_founder'].get('title') or '')[:30] for c in selected).most_common(8))
