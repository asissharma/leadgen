#!/usr/bin/env python3
"""Funding-recency trigger: SEC EDGAR full-text search for Form D (US private placements).
Flags companies with recent Form D filings = just raised = prime CoS hiring window."""
import requests, json, time, re
S = requests.Session()
S.headers.update({'User-Agent': 'IndividualJobSeeker research jobsearch.research@proton.me', 'Accept': 'application/json'})
rows = json.load(open('leadgen/results/rows_enriched.json'))
us = [r for r in rows if r['Country/City'].startswith('US')]
print(f'US rows: {len(us)}')
flags = {}
for r in us:
    name = r['Company'].replace(', Inc.','').replace(' Inc.','').replace(', Inc','').strip()
    if len(name) < 4 or re.match(r'^(Zip|Metal|Gather|Infinity|Jeeves|Twenty|Campfire|Char)$', name, re.I):
        flags[r['Company']] = {'ambiguous_common_name': True}; continue
    try:
        resp = S.get('https://efts.sec.gov/LATEST/search-index',
                     params={'q': f'"{name}"', 'forms': 'D'}, timeout=15)
        if resp.status_code != 200: flags[r['Company']] = {'error': resp.status_code}; continue
        hits = resp.json().get('hits', {}).get('hits', [])
        dates = sorted({h.get('_source', {}).get('file_date', '') for h in hits}, reverse=True)
        recent = [d for d in dates if d >= '2025-01-01']
        flags[r['Company']] = {'n_formd': len(hits), 'latest': dates[0] if dates else None, 'recent_2025plus': recent[:3]}
        if recent: print(f"  RAISED? {name}: Form D filed {recent[:2]}")
    except Exception as e:
        flags[r['Company']] = {'error': str(e)[:60]}
    time.sleep(0.25)

# annotate rows
for r in rows:
    f = flags.get(r['Company'])
    if f and f.get('recent_2025plus'):
        note = f" || FUNDING TRIGGER: SEC Form D filed {f['recent_2025plus'][0]} (recent raise - prime CoS window; verify entity match)"
        if 'FUNDING TRIGGER' not in r['Notes']: r['Notes'] += note
json.dump(rows, open('leadgen/results/rows_enriched.json','w'), indent=1)
json.dump(flags, open('leadgen/data/edgar_formd.json','w'), indent=1)
n_recent = sum(1 for f in flags.values() if f.get('recent_2025plus'))
n_any = sum(1 for f in flags.values() if f.get('n_formd'))
print(f'DONE: {n_recent}/{len(us)} US companies with Form D filed 2025+ ; {n_any} with any Form D history')
