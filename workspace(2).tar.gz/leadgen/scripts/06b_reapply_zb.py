#!/usr/bin/env python3
"""Re-apply the 6 real ZeroBounce verdicts from the 2026-10-01 pass (key ran out of credits mid-batch).
These were actual API responses, recorded in logs/enrich.log and the session record."""
import json, csv, re, os
VERDICTS = {
  'david.eberle@typewise.app': {'status':'verified (ZeroBounce: valid)', 'conf':'high', 'catchall':False},
  'justin@prosights.co':       {'status':'verified* (ZeroBounce: valid, catch-all domain)', 'conf':'medium', 'catchall':True},
  'vishubansal@acciojob.com':  {'status':'DEAD', 'sub':'mailbox_not_found'},
  'shikhar.shrestha@ambient.ai':{'status':'DEAD', 'sub':'mailbox_not_found'},
  'johnglasgow@campfire.ai':   {'status':'DEAD', 'sub':'mailbox_not_found'},
}
rows = json.load(open('leadgen/results/rows.json'))
supp = []
for r in rows:
    em = r.get('Work email','')
    v = VERDICTS.get(em)
    if not v: continue
    if v['status'] == 'DEAD':
        first = r['Full name'].split()[0].lower(); last = r['Full name'].split()[-1].lower(); dom = r['Company domain']
        alts = [a for a in (f'{first}@{dom}', f'{first}.{last}@{dom}', f'{first}{last}@{dom}') if a != em][:2]
        r['Notes'] += f' | DEAD mailbox (ZeroBounce 2026-10-01: {v["sub"]}): {em} — suppressed; untested fallbacks: {", ".join(alts)}'
        r['Work email'] = ''; r['Email status'] = 'DEAD - do not use (ZeroBounce: mailbox_not_found)'; r['Email source'] = ''; r['Confidence'] = 'low'
        supp.append({'email': em, 'name': r['Full name'], 'company': r['Company'], 'reason': f'zerobounce:invalid/{v["sub"]}', 'date': '2026-10-01', 'source': '06b_reapply_zb'})
    else:
        r['Email status'] = v['status']; r['Confidence'] = v['conf']; r['Email source'] = (r.get('Email source') or '') + ' + ZeroBounce'
        if v['catchall']:
            r['Notes'] += '; catch-all domain: mailbox accepted at SMTP level but domain accepts ALL addresses - personalize carefully and watch bounces'
json.dump(rows, open('leadgen/results/rows_enriched.json','w'), indent=1)
with open('leadgen/results/suppression_list.csv','w',newline='',encoding='utf-8') as f:
    w = csv.DictWriter(f, fieldnames=['email','name','company','reason','date','source']); w.writeheader(); w.writerows(supp)
print('re-applied', len(VERDICTS), 'verdicts;', len(supp), 'suppressions')
