import requests, re, json, time, sys
sys.path.insert(0, 'leadgen/scripts')
import dns.resolver

UAH = {'User-Agent': 'job-search-research', 'Accept': 'application/vnd.github+json'}
S2 = {'co.uk','com.au','co.in','com.br','com.mx','co.nz','co.za','com.sg','com.tr','com.pk','co.id','com.vn','com.ar','com.co','com.pe','co.kr','co.jp','com.cn','com.hk','com.tw','co.il','com.ua','com.ph','com.my','co.ke','com.ng','co.th','lk'}
def reg_domain(host):
    host = host.lower()
    if host.startswith('www.'): host = host[4:]
    p = host.split('.')
    if len(p) >= 3 and '.'.join(p[-2:]) in S2: return '.'.join(p[-3:])
    return '.'.join(p[-2:]) if len(p) >= 2 else host

def name_variants(full_name):
    t = [x for x in re.sub(r'[^\w\s]', ' ', full_name).split() if x]
    if not t: return set(), ('','')
    first, last = t[0].lower(), t[-1].lower()
    mid = ''.join(x[0] for x in t[1:-1])
    v = {first, last, f'{first}.{last}', f'{first}{last}', f'{first[0]}{last}', f'{first[0]}.{last}',
         f'{first}_{last}', f'{last}.{first}', f'{last}{first}', f'{first}{mid}{last}', f'{first}.{mid}.{last}'}
    return {re.sub(r'[._-]', '', x) for x in v}, (first, last)

def detect_pattern(name, email):
    lp = email.split('@')[0].lower()
    t = [x for x in re.sub(r'[^\w\s]', ' ', name).split() if x]
    if len(t) < 2: return None
    first, last = t[0].lower(), t[-1].lower()
    lpd = re.sub(r'[._-]', '', lp)
    if lpd == f'{first}{last}': return 'firstlast' if '.' not in lp and '_' not in lp else 'first.last'
    if lpd == f'{last}{first}': return 'lastfirst'
    if lpd == f'{first[0]}{last}': return 'flast'
    if lpd == f'{first}{last[0]}': return 'firstl'
    if lpd == first: return 'first'
    if lpd == last: return 'last'
    if lpd.startswith(first[0]) and lpd.endswith(last): return 'f.last-ish'
    return 'other'

def gh(url):
    try:
        r = requests.get(url, timeout=15, headers=UAH)
        if r.status_code == 403 and 'rate limit' in r.text.lower(): return None, 'RATELIMIT'
        if r.status_code == 404: return None, '404'
        if not r.ok: return None, str(r.status_code)
        return r.json(), None
    except Exception as e:
        return None, str(e)[:60]

recs = [json.loads(l) for l in open('leadgen/data/people_target.jsonl')]
site = {}
for l in open('leadgen/data/site_enrich.jsonl'):
    d = json.loads(l); site[d['slug']] = d

gh_out = {}
budget = 56
used = 0
for rec in recs:
    g = rec.get('github_url')
    if not g or used >= budget: continue
    if site.get(rec['slug'], {}).get('attributed_emails'): continue
    org = g.rstrip('/').split('/')[-1]
    repos, err = gh(f'https://api.github.com/orgs/{org}/repos?sort=pushed&per_page=8&type=public'); used += 1
    if err == 'RATELIMIT': print('rate limited, stopping github phase'); break
    if not repos: 
        gh_out[rec['slug']] = {'error': err or 'no repos'}; continue
    pairs, team_emails = [], []
    for rp in repos[:2]:
        if used >= budget: break
        if rp.get('fork'): continue
        commits, err2 = gh(f"https://api.github.com/repos/{org}/{rp['name']}/commits?per_page=60"); used += 1
        if not commits: continue
        for c in commits:
            a = (c.get('commit') or {}).get('author') or {}
            em = (a.get('email') or '').lower(); nm = a.get('name') or ''
            if not em or 'noreply' in em or 'users.noreply' in em: continue
            if reg_domain(em.split('@')[-1]) == reg_domain(rec.get('website') or ''):
                team_emails.append({'name': nm, 'email': em})
                p = detect_pattern(nm, em)
                if p and p != 'other': pairs.append(p)
    fn = rec['best_founder']['full_name'] or ''
    nv, (first, last) = name_variants(fn)
    founder_hits = [t for t in team_emails if re.sub(r'[._-]', '', t['email'].split('@')[0]) in nv]
    from collections import Counter
    pat = Counter(pairs).most_common(1)
    gh_out[rec['slug']] = {'org': org, 'team_emails': team_emails[:15], 'founder_hits': founder_hits,
                            'pattern': pat[0][0] if pat else None, 'pattern_count': pat[0][1] if pat else 0,
                            'n_commits_emails': len(team_emails)}
    if founder_hits or pat:
        print(rec['slug'], '| founder_hit:', bool(founder_hits), '| pattern:', pat[0][0] if pat else None, f"({pat[0][1] if pat else 0} samples)")

# MX checks for all domains
mx_out = {}
res = dns.resolver.Resolver(); res.lifetime = 6
for rec in recs:
    w = rec.get('website') or ''
    d = reg_domain(re.sub(r'^https?://', '', w).split('/')[0]) if w else None
    if not d or d in mx_out: continue
    try:
        ans = res.resolve(d, 'MX')
        mx_out[d] = [str(a.exchange).rstrip('.') for a in ans][:3]
    except Exception:
        mx_out[d] = []
    time.sleep(0.05)

json.dump({'github': gh_out, 'mx': mx_out, 'gh_requests_used': used}, open('leadgen/data/gh_mx.json','w'), indent=1)
nhit = sum(1 for v in gh_out.values() if v.get('founder_hits'))
npat = sum(1 for v in gh_out.values() if v.get('pattern'))
nmx = sum(1 for v in mx_out.values() if v)
print(f'GITHUB: orgs={len(gh_out)} founder_email_hits={nhit} orgs_with_pattern={npat} api_calls={used}')
print(f'MX: domains={len(mx_out)} with_mx={nmx} without_mx={[k for k,v in mx_out.items() if not v]}')
