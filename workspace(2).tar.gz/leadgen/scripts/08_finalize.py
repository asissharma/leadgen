import json, re, csv
rows = json.load(open('leadgen/out/rows_enriched.json'))

def parts(fn):
    t = [x for x in re.sub(r"[^\w\s]", " ", fn).split() if len(x) > 1]
    return (t[0].lower(), t[-1].lower()) if len(t) >= 2 else ('', '')

for r in rows:
    # 1) clean zb error noise
    r['Email status'] = re.sub(r'\s*\|\s*zb:None', '', r['Email status']).strip()
    # 2) DEAD rows: pull email out of the outreach column, keep audit + fallbacks in Notes
    if r['Email status'].startswith('DEAD'):
        dead = r['Work email']; first, last = parts(r['Full name']); dom = r['Company domain']
        alts = [a for a in (f'{first}@{dom}', f'{first}.{last}@{dom}', f'{first}{last}@{dom}', f'{first[0]}{last}@{dom}') if a != dead]
        r['Notes'] += f' | DEAD mailbox (ZeroBounce: mailbox_not_found): {dead} — suppressed; untested fallbacks: {", ".join(alts[:2])} (verify when credits reset)'
        r['Work email'] = ''
        r['Email source'] = ''

json.dump(rows, open('leadgen/out/rows_enriched.json', 'w'), indent=1)

cols = ['Full name','Title','Company','Company domain','Headcount band','Industry','Country/City','LinkedIn URL','Work email','Email status','Email source','Phone','Phone type','Phone source','Other channels','Confidence','Date collected','Notes']
rows.sort(key=lambda r: ({'high':0,'medium':1,'low':2}[r['Confidence']], r['Company']))
with open('leadgen/out/contacts_enriched.csv','w',newline='',encoding='utf-8-sig') as f:
    w = csv.DictWriter(f, fieldnames=cols, extrasaction='ignore'); w.writeheader(); w.writerows(rows)

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter
wb = Workbook(); ws = wb.active; ws.title = 'Contacts (verified pass)'
ws.append(cols)
hf = PatternFill('solid', fgColor='1F4E79')
for c in ws[1]: c.font = Font(bold=True, color='FFFFFF'); c.fill = hf; c.alignment = Alignment(vertical='center')
conf_fill = {'high': PatternFill('solid', fgColor='C6EFCE'), 'medium': PatternFill('solid', fgColor='FFEB9C'), 'low': PatternFill('solid', fgColor='FFC7CE')}
for r in rows:
    ws.append([r.get(c,'') for c in cols])
    ws.cell(ws.max_row, cols.index('Confidence')+1).fill = conf_fill.get(r['Confidence'], PatternFill())
    st = r.get('Email status','')
    if st.startswith('verified ('): ws.cell(ws.max_row, cols.index('Email status')+1).fill = conf_fill['high']
    elif st.startswith('DEAD'): ws.cell(ws.max_row, cols.index('Email status')+1).fill = conf_fill['low']
widths = [22,20,18,18,13,22,16,38,32,34,26,18,20,30,50,11,12,70]
for i,wd in enumerate(widths,1): ws.column_dimensions[get_column_letter(i)].width = wd
ws.freeze_panes = 'A2'; ws.auto_filter.ref = ws.dimensions
ws2 = wb.create_sheet('Verification log')
ws2.append(['Outcome','Count','Detail'])
from collections import Counter
c = Counter()
for r in rows:
    s = r['Email status']
    if s.startswith('verified ('): c['verified (SMTP-valid, non-catch-all)'] += 1
    elif s.startswith('verified*'): c['verified* (valid but catch-all domain)'] += 1
    elif s.startswith('DEAD'): c['DEAD - suppressed'] += 1
    elif s.startswith('none'): c['no email (domain has no MX)'] += 1
    elif 'real domain pattern' in s: c['inferred from real domain pattern (unverified)'] += 1
    elif 'convention' in s: c['inferred from convention (unverified)'] += 1
    else: c['other'] += 1
for k,v in c.most_common(): ws2.append([k,v,''])
ws2.append([])
ws2.append(['ZeroBounce credits used','6 of account balance','1 test + 5 batch before "ran out of credits"; 92 rows pending re-run'])
ws2.append(['Apollo API','not available on Free plan','403 API_INACCESSIBLE - use Apollo web UI manually (free) per runbook §5'])
ws2.append(['Suppression list','3 entries','out/suppression_list.csv - check before every send'])
wb.save('leadgen/out/contacts_enriched.xlsx')

print('final stats:', dict(c))
print('conf:', Counter(r['Confidence'] for r in rows))
print('emails usable:', sum(1 for r in rows if r['Work email']))
