#!/usr/bin/env python3
"""Hiring-signal radar: for each target company, find its public ATS job board
(Greenhouse/Lever/Ashby/BambooHR - official public JSON APIs) and flag
CoS / Founder's Office / ops roles. Plus HN Who's Hiring scan via public Algolia API."""
import requests, re, json, time, html as H
from urllib.parse import urlparse
from concurrent.futures import ThreadPoolExecutor, as_completed

UA = {'User-Agent': 'Mozilla/5.0 (compatible; job-search-research/1.0)'}
S = requests.Session(); S.headers.update(UA)

HOT = re.compile(r"(chief of staff|founder'?s? office|founding (team )?(operations|ops)|head of (business )?operations|strategy (&|and) ops|strategic operations|business operations|bizops|executive assistant to (the )?(ceo|founder)|chief of ops)", re.I)
WARM = re.compile(r"(operations manager|ops manager|program manager|general manager|vp (of )?operations|director of operations|head of ops|founding|strategy|biz dev ops|revenue operations|sales operations|people operations|operating)", re.I)

recs = [json.loads(l) for l in open('leadgen/data/people_target.jsonl')]
site = {json.loads(l)['slug']: json.loads(l) for l in open('leadgen/data/site_enrich.jsonl')}

def domain_name(rec):
    w = rec.get('website') or ''
    host = re.sub(r'^https?://', '', w).split('/')[0]
    host = re.sub(r'^www\.', '', host)
    name = host.split('.')[0] if host else ''
    return name

def slug_candidates(rec):
    c = []
    dn = domain_name(rec)
    yc = rec['slug']
    nm = re.sub(r'[^a-z0-9]', '', (rec.get('name') or '').lower())
    for base in (dn, yc, nm):
        if not base: continue
        for v in (base, 'try'+base, 'get'+base, 'use'+base, base+'hq', base+'app', base+'io'):
            if v not in c: c.append(v)
    return c[:8]

def find_ats_links(rec):
    """re-fetch homepage, look for careers links + ATS embeds"""
    out = {'greenhouse': set(), 'lever': set(), 'ashby': set(), 'bamboo': set(), 'careers_pages': set()}
    w = rec.get('website')
    if not w: return out
    if not w.startswith('http'): w = 'https://' + w
    try:
        r = S.get(w, timeout=12)
        if r.status_code >= 400: return out
        h = H.unescape(r.text)
        out['greenhouse'] |= set(re.findall(r'(?:boards|jobs)\.greenhouse\.io/(?:embed/)?([\w\-]+)', h, re.I))
        out['lever']    |= set(re.findall(r'(?:jobs|apply)\.lever\.co/([\w\-]+)', h, re.I))
        out['ashby']    |= set(re.findall(r'(?:jobs|careers)\.ashbyhq\.com/([\w\-\.]+)', h, re.I))
        out['bamboo']   |= set(re.findall(r'https?://([\w\-]+)\.bamboohr\.com', h, re.I))
        links = set(re.findall(r'href=["\']([^"\']*(?:career|jobs?|jobs-?board|openings|work-?with-?us|vacanc)[^"\']*)["\']', h, re.I))
        for l in list(links)[:2]:
            from urllib.parse import urljoin
            out['careers_pages'].add(urljoin(w, l))
    except Exception:
        pass
    return out

def classify(jobs):
    hot, warm = [], []
    for t, u in jobs:
        if HOT.search(t): hot.append({'title': t, 'url': u})
        elif WARM.search(t): warm.append({'title': t, 'url': u})
    return hot, warm

def fetch_boards(rec):
    ats = find_ats_links(rec)
    jobs, source = [], None
    # Greenhouse
    tokens = list(ats['greenhouse']) + [c for c in slug_candidates(rec)]
    for tk in dict.fromkeys(tokens):
        try:
            r = S.get(f'https://boards-api.greenhouse.io/v1/boards/{tk}/jobs', timeout=10)
            if r.status_code == 200:
                d = r.json().get('jobs') or []
                if d: jobs = [(j.get('title',''), j.get('absolute_url','')) for j in d]; source = f'greenhouse:{tk}'; break
        except Exception: pass
        time.sleep(0.1)
    # Lever
    if not jobs:
        for tk in dict.fromkeys(list(ats['lever']) + slug_candidates(rec)):
            try:
                r = S.get(f'https://api.lever.co/v0/postings/{tk}?mode=json', timeout=10)
                if r.status_code == 200:
                    d = r.json()
                    if isinstance(d, list) and d:
                        jobs = [(j.get('text',''), (j.get('hostedUrl') or j.get('applyUrl') or '')) for j in d]; source = f'lever:{tk}'; break
            except Exception: pass
            time.sleep(0.1)
    # Ashby
    if not jobs:
        for tk in dict.fromkeys(list(ats['ashby']) + slug_candidates(rec)):
            try:
                r = S.get(f'https://api.ashbyhq.com/posting-api/job-board/{tk}', timeout=10)
                if r.status_code == 200:
                    d = (r.json() or {}).get('jobs') or []
                    if d:
                        jobs = [(j.get('title',''), j.get('jobUrl') or j.get('applyUrl') or '') for j in d]; source = f'ashby:{tk}'; break
            except Exception: pass
            time.sleep(0.1)
    # BambooHR
    if not jobs:
        for tk in dict.fromkeys(list(ats['bamboo']) + slug_candidates(rec)[:3]):
            try:
                r = S.get(f'https://{tk}.bamboohr.com/careers/list', timeout=10, headers={'Accept':'application/json'})
                if r.status_code == 200:
                    res = (r.json() or {}).get('result') or []
                    flat = []
                    for grp in res:
                        flat += grp.get('jobs') or [] if isinstance(grp, dict) else []
                    if flat:
                        jobs = [(j.get('jobOpeningName',''), f'https://{tk}.bamboohr.com/careers/{j.get("id")}') for j in flat]; source = f'bamboo:{tk}'; break
            except Exception: pass
            time.sleep(0.1)
    hot, warm = classify(jobs)
    return {'slug': rec['slug'], 'company': rec['name'], 'ats': source, 'n_open_roles': len(jobs),
            'hot_roles': hot[:8], 'warm_roles': warm[:8],
            'careers_pages': list(ats['careers_pages'])[:2]}

results = []
t0 = time.time()
with ThreadPoolExecutor(max_workers=4) as ex:
    futs = {ex.submit(fetch_boards, r): r for r in recs}
    for i, f in enumerate(as_completed(futs), 1):
        results.append(f.result())
        if i % 25 == 0: print(f'{i}/{len(recs)} scanned, {time.time()-t0:.0f}s', flush=True)

# --- HN Who's Hiring scan (official public Algolia API) ---
hn_hits = []
try:
    for q in ('"chief of staff"', '"founding operations"', '"founder\'s office"'):
        r = S.get('https://hn.algolia.com/api/v1/search_by_date',
                  params={'query': q, 'tags': 'comment', 'hitsPerPage': 40, 'numericFilters': f'created_at_i>{int(time.time())-150*86400}'},
                  timeout=20)
        for hit in r.json().get('hits', []):
            txt = hit.get('comment_text') or ''
            if re.search(r'(who is hiring|we.re hiring|yc |y combinator)', txt, re.I):
                em = re.findall(r'[\w.\-]+@[\w.\-]+\.\w+', txt)
                m = re.search(r'<b>([^<]{2,60})</b>', txt) or re.search(r'^([^|\n<]{2,60})', re.sub(r'<[^>]+>', '', txt))
                hn_hits.append({'query': q, 'company_hint': (m.group(1).strip() if m else ''), 'email': em[0] if em else '',
                                'story': hit.get('story_title'), 'hn': f"https://news.ycombinator.com/item?id={hit.get('objectID')}",
                                'when': hit.get('created_at','')[:10], 'snippet': re.sub(r'<[^>]+>', ' ', txt)[:300]})
        time.sleep(1)
except Exception as e:
    print('HN scan error:', e)

json.dump({'company_signals': results, 'hn_whos_hiring': hn_hits}, open('leadgen/data/hiring_signals.json','w'), indent=1)
nb = sum(1 for r in results if r['ats'])
hot = [r for r in results if r['hot_roles']]
warm = [r for r in results if r['warm_roles'] and not r['hot_roles']]
print(f'DONE {time.time()-t0:.0f}s | boards found: {nb}/{len(results)} | HOT (CoS/FounderOffice roles open): {len(hot)} | WARM (ops roles only): {len(warm)} | HN hits: {len(hn_hits)}')
for r in hot: print('HOT:', r['company'], '->', [x['title'] for x in r['hot_roles']][:3])
