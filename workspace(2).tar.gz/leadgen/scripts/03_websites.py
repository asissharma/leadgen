import requests, re, json, time, sys, os
from urllib.parse import urljoin, urlparse
from urllib import robotparser
from concurrent.futures import ThreadPoolExecutor, as_completed

UA = {'User-Agent': 'Mozilla/5.0 (compatible; job-search-research/1.0; +individual jobseeker)'}
EMAIL_RE = re.compile(r'[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}')
PHONE_RE = re.compile(r'(?:\+\d{1,3}[\s.\-]?\(?\d{1,4}\)?[\s.\-]?\d{2,4}[\s.\-]?\d{2,4}(?:[\s.\-]?\d{2,4})?|\(\d{3}\)[\s.\-]?\d{3}[\s.\-]?\d{4})')
SUBPAGE_RE = re.compile(r'(about|team|contact|press|imprint|legal|privacy|kontakt|contacto|equipe|qui-sommes|company|people|leadership|management)', re.I)
LINKEDIN_RE = re.compile(r'https?://(?:[a-z]{2,3}\.)?linkedin\.com/in/[\w\-%]+', re.I)
X_RE = re.compile(r'https?://(?:www\.)?(?:twitter\.com|x\.com)/[A-Za-z0-9_]{2,20}', re.I)
BAD_EMAIL_DOMAINS = {'example.com','sentry.io','wixpress.com','sentry-next.wixpress.com','domain.com','email.com','yourdomain.com','gmail.com.png','2x'}
IMG_EXT = re.compile(r'\.(png|jpe?g|webp|svg|gif|css|js|woff2?)(\.|$)', re.I)

S2 = {'co.uk','com.au','co.in','com.br','com.mx','co.nz','co.za','com.sg','com.tr','com.pk','co.id','com.vn','com.ar','com.co','com.pe','co.kr','co.jp','com.cn','com.hk','com.tw','co.il','com.ua','com.ph','com.my','co.ke','com.ng','com.eg','com.sa','co.th','com.bd','lk'}
def reg_domain(host):
    host = host.lower().lstrip('www.') if host.lower().startswith('www.') else host.lower()
    p = host.split('.')
    if len(p) >= 3 and '.'.join(p[-2:]) in S2: return '.'.join(p[-3:])
    return '.'.join(p[-2:]) if len(p) >= 2 else host

def fetch(url, sess):
    try:
        r = sess.get(url, timeout=12, allow_redirects=True)
        if r.status_code >= 400: return None, r.status_code
        ct = r.headers.get('content-type','')
        if 'html' not in ct and 'text' not in ct: return None, 'ct:'+ct[:20]
        if len(r.content) > 3_000_000: r._content = r.content[:3_000_000]
        return r, r.status_code
    except Exception:
        try:
            r = sess.get(url, timeout=12, verify=False, allow_redirects=True)
            if r.status_code < 400: return r, r.status_code
        except Exception: pass
        return None, 'err'

def mine(html_text, page_url):
    emails = set()
    for m in re.findall(r'mailto:([^"\'?>\s]+)', html_text, re.I): emails.add(m.strip())
    for e in EMAIL_RE.findall(html_text): emails.add(e.strip())
    clean = set()
    for e in emails:
        e = e.strip('.;,')
        if IMG_EXT.search(e): continue
        d = e.split('@')[-1].lower()
        if d in BAD_EMAIL_DOMAINS: continue
        if len(e) > 70: continue
        clean.add(e.lower())
    phones = set(p.strip() for p in PHONE_RE.findall(html_text))
    digits_ok = {p for p in phones if 8 <= sum(c.isdigit() for c in p) <= 15}
    links = set(re.findall(r'href=["\']([^"\']+)["\']', html_text, re.I))
    subs = {urljoin(page_url, l) for l in links if SUBPAGE_RE.search(l) and not l.startswith(('mailto:','tel:','#','javascript'))}
    return clean, digits_ok, subs, set(LINKEDIN_RE.findall(html_text)), set(X_RE.findall(html_text)), html_text

def name_variants(full_name):
    t = re.sub(r'[^\w\s]', ' ', full_name).split()
    t = [x for x in t if len(x) > 1 or x == t[0][:1]]
    if not t: return set()
    first, last = t[0].lower(), t[-1].lower()
    mid = ''.join(x[0] for x in t[1:-1]).lower()
    v = {first, last, f'{first}.{last}', f'{first}{last}', f'{first[0]}{last}', f'{first[0]}.{last}',
         f'{first}_{last}', f'{last}.{first}', f'{last}{first}', f'{first}{mid}{last}', f'{first}.{mid}.{last}',
         f'{first[0]}{mid}{last}'}
    return {re.sub(r'[._\-]', '', x) for x in v}

def process(rec):
    sess = requests.Session(); sess.headers.update(UA)
    out = {'slug': rec['slug'], 'website': rec.get('website'), 'emails': [], 'phones': [],
           'linkedin_in': [], 'x_links': [], 'pages_fetched': [], 'errors': [], 'reachable': False}
    site = rec.get('website')
    if not site: out['errors'].append('no website'); return out
    if not site.startswith('http'): site = 'https://' + site
    host = urlparse(site).netloc or urlparse(site).path
    dom = reg_domain(host)
    out['domain'] = dom
    rp = robotparser.RobotFileParser()
    try:
        rr = requests.get(f'{urlparse(site).scheme}://{host}/robots.txt', timeout=8, headers=UA)
        rp.parse(rr.text.splitlines() if rr.status_code < 400 else [])
    except Exception:
        rp.parse([])  # no robots -> allowed
    def allowed(u):
        try: return rp.can_fetch(UA['User-Agent'], u)
        except Exception: return True
    r, st = fetch(site, sess)
    if not r: out['errors'].append(f'home:{st}'); 
    else:
        out['reachable'] = True; out['pages_fetched'].append(r.url)
        emails, phones, subs, lins, xs, _ = mine(r.text, r.url)
        out['emails'] += [{'email': e, 'page': 'home'} for e in emails]
        out['phones'] += [{'phone': p, 'page': 'home'} for p in phones]
        out['linkedin_in'] += list(lins); out['x_links'] += list(xs)
        # subpages: contact/impressum first
        subs = sorted(subs, key=lambda u: (0 if re.search(r'contact|imprint|kontakt|contacto', u, re.I) else 1))[:3]
        for s in subs:
            if urlparse(s).netloc and reg_domain(urlparse(s).netloc) != dom: continue
            if not allowed(s): out['errors'].append(f'robots:{s}'); continue
            time.sleep(0.3)
            r2, st2 = fetch(s, sess)
            if not r2: continue
            out['pages_fetched'].append(r2.url)
            e2, p2, _, l2, x2, _ = mine(r2.text, r2.url)
            out['emails'] += [{'email': e, 'page': r2.url} for e in e2]
            out['phones'] += [{'phone': p, 'page': r2.url} for p in p2]
            out['linkedin_in'] += list(l2); out['x_links'] += list(x2)
    # dedupe
    seen = set(); oe = []
    for e in out['emails']:
        if e['email'] not in seen: seen.add(e['email']); oe.append(e)
    out['emails'] = oe
    seen = set(); op = []
    for p in out['phones']:
        key = re.sub(r'\D', '', p['phone'])[-9:]
        if key not in seen: seen.add(key); op.append(p)
    out['phones'] = op
    out['linkedin_in'] = list(dict.fromkeys(out['linkedin_in']))[:8]
    out['x_links'] = list(dict.fromkeys(out['x_links']))[:5]
    # attribute emails to founder by name pattern
    fn = rec['best_founder']['full_name'] or ''
    nv = name_variants(fn)
    attributed = []
    for e in out['emails']:
        lp, d = e['email'].split('@', 1) if '@' in e['email'] else ('','')
        if reg_domain(d) != dom: continue
        lpn = re.sub(r'[._\-]', '', lp)
        if lpn in nv or lp in nv: attributed.append(e['email'])
    out['attributed_emails'] = attributed
    out['same_domain_emails'] = [e['email'] for e in out['emails'] if '@' in e['email'] and reg_domain(e['email'].split('@')[-1]) == dom]
    return out

recs = [json.loads(l) for l in open('leadgen/data/people_target.jsonl')]
results = []
t0 = time.time()
with ThreadPoolExecutor(max_workers=6) as ex:
    futs = {ex.submit(process, r): r for r in recs}
    done = 0
    for fut in as_completed(futs):
        results.append(fut.result()); done += 1
        if done % 20 == 0: print(f'{done}/{len(recs)} sites done, {time.time()-t0:.0f}s', flush=True)

with open('leadgen/data/site_enrich.jsonl','w') as f:
    for r in results: f.write(json.dumps(r)+'\n')

reach = sum(1 for r in results if r['reachable'])
withmail = sum(1 for r in results if r['same_domain_emails'])
attr = sum(1 for r in results if r['attributed_emails'])
ph = sum(1 for r in results if r['phones'])
li = sum(1 for r in results if r['linkedin_in'])
print(f'DONE. reachable={reach}/{len(results)} sites_with_same_domain_email={withmail} founder_attributed={attr} any_phone={ph} any_linkedin_in={li} time={time.time()-t0:.0f}s')
