#!/usr/bin/env python3
"""
Optional freemium upgrade pass. Paste keys as env vars; the script verifies/
enriches contacts.csv within free-tier budgets, updates statuses, appends
invalid addresses to suppression_list.csv, and writes contacts_enriched.{csv,xlsx}.

  export ZEROBOUNCE_API_KEY=...   # free: 100 validations/month  -> https://www.zerobounce.net (Sign up free)
  export HUNTER_API_KEY=...       # free: ~50 credits/month      -> https://hunter.io (Sign up -> API key in dashboard)
  export APOLLO_API_KEY=...       # free plan                    -> https://www.apollo.io (Settings -> Integrations -> API)

Usage: python3 07_enrich_with_keys.py --zerobounce 100 --hunter 25 --apollo 0
"""
import os, sys, json, csv, time, argparse, logging
import requests

LOG = 'leadgen/logs/enrich.log'
os.makedirs('leadgen/logs', exist_ok=True)
logging.basicConfig(level=logging.INFO, format='%(asctime)s %(message)s',
                    handlers=[logging.FileHandler(LOG), logging.StreamHandler()])
log = logging.info

def load_rows():
    p = 'leadgen/results/rows_enriched.json'
    if not os.path.exists(p): p = 'leadgen/results/rows.json'
    if os.path.exists(p): return json.load(open(p))
    rows = list(csv.DictReader(open('leadgen/results/contacts.csv', encoding='utf-8-sig')))
    return rows

def zb_verify(email, key):
    r = requests.get('https://api.zerobounce.net/v2/validate',
                     params={'api_key': key, 'email': email}, timeout=20)
    if r.status_code == 429: return {'status': 'RATELIMIT'}
    r.raise_for_status()
    d = r.json()
    if 'error' in d: return {'status': None, 'sub': None, 'error': d['error']}
    return {'status': d.get('status'), 'sub': d.get('sub_status'), 'catchall': d.get('catchall_domain') in (True,'true')}

def hunter_verify(email, key):
    r = requests.get('https://api.hunter.io/v2/email-verifier',
                     params={'email': email, 'api_key': key}, timeout=20)
    if r.status_code == 429: return {'score': None, 'result': 'RATELIMIT'}
    r.raise_for_status()
    d = r.json().get('data', {})
    return {'score': d.get('score'), 'result': d.get('result')}

def apollo_match(row, key):
    fn = row['Full name'].split()[0]; ln = row['Full name'].split()[-1]
    payload = {'first_name': fn, 'last_name': ln, 'domain': row['Company domain'],
               'reveal_personal_emails': False}
    r = requests.post('https://api.apollo.io/api/v1/people/match', json=payload,
                      headers={'x-api-key': key, 'Content-Type': 'application/json',
                               'Cache-Control': 'no-cache'}, timeout=25)
    if r.status_code in (401, 403): return {'error': f'auth/plan ({r.status_code}): free-plan API access may require enabling in Apollo settings'}
    if r.status_code == 429: return {'error': 'RATELIMIT'}
    if not r.ok: return {'error': str(r.status_code)}
    p = r.json().get('person') or {}
    out = {}
    if p.get('email'): out['email'] = p['email']; out['email_status'] = 'verified (Apollo)' if p.get('email_status') == 'verified' else 'provided (Apollo, unverified)'
    if p.get('linkedin_url'): out['linkedin'] = p['linkedin_url']
    for ph in (p.get('phone_numbers') or []):
        if ph.get('raw_number'): out.setdefault('phone', ph['raw_number']); out['phone_type'] = ph.get('type', 'direct')
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--zerobounce', type=int, default=100)
    ap.add_argument('--hunter', type=int, default=25)
    ap.add_argument('--apollo', type=int, default=0, help='max Apollo match calls (uses mobile credits - keep low on free plan)')
    a = ap.parse_args()
    ZB, HU, AP = os.getenv('ZEROBOUNCE_API_KEY'), os.getenv('HUNTER_API_KEY'), os.getenv('APOLLO_API_KEY')
    if not any([ZB, HU, AP]):
        print(__doc__); print('No keys found in environment. Add at least one and re-run.'); sys.exit(1)
    rows = load_rows()
    conf_rank = {'high': 0, 'medium': 1, 'low': 2}
    todo = sorted([r for r in rows if r.get('Work email')], key=lambda r: conf_rank.get(r.get('Confidence', 'low'), 3))
    supp_path = 'leadgen/results/suppression_list.csv'
    new_supp = []
    zb_n = hu_n = ap_n = 0
    for row in todo:
        em = row['Work email']
        already = ('ZeroBounce' in (row.get('Email status') or '')) or (row.get('Email status') or '').startswith(('verified','DEAD','risky'))
        # ZeroBounce pass
        if ZB and zb_n < a.zerobounce and not already:
            try:
                res = zb_verify(em, ZB); zb_n += 1; time.sleep(1.0)
                if res.get('status') == 'RATELIMIT': log('ZeroBounce rate limit hit; stopping ZB'); ZB = None
                elif res.get('error'): log(f'ZeroBounce: {res["error"]} - stopping ZB pass'); ZB = None
                elif res.get('status') == 'valid':
                    row['Email source'] = (row.get('Email source') or '') + ' + ZeroBounce'
                    if res.get('catchall'):
                        row['Email status'] = 'verified* (ZeroBounce: valid, catch-all domain)'
                        row['Confidence'] = 'medium'
                        row['Notes'] = (row.get('Notes') or '') + '; catch-all domain: mailbox accepted at SMTP level but domain accepts ALL addresses - personalize carefully and watch bounces'
                    else:
                        row['Email status'] = 'verified (ZeroBounce: valid)'; row['Confidence'] = 'high'
                elif res.get('status') == 'catch_all':
                    row['Email status'] = 'risky (ZeroBounce: catch-all domain)'
                elif res.get('status') in ('invalid', 'spamtrap', 'abuse'):
                    row['Email status'] = 'DEAD - do not use'; row['Confidence'] = 'low'
                    new_supp.append({'email': em, 'name': row['Full name'], 'company': row['Company'],
                                     'reason': f'zerobounce:{res.get("status")}/{res.get("sub")}', 'date': time.strftime('%F'), 'source': '07_enrich'})
                elif res.get('status'):
                    row['Email status'] = (row.get('Email status') or '') + f' | zb:{res.get("status")}'
                    log(f'ZB {em} -> {res.get("status")}/{res.get("sub")}')
                else:
                    log(f'ZB {em} -> no verdict (credits/error)')
            except Exception as e:
                log(f'ZB error {em}: {e}')
        # Hunter pass for anything still unverified-inferred
        if HU and hu_n < a.hunter and 'verified' not in row['Email status'] and 'DEAD' not in row['Email status']:
            try:
                res = hunter_verify(em, HU); hu_n += 1; time.sleep(1.2)
                if res.get('result') == 'RATELIMIT': log('Hunter rate limit; stopping HU'); HU = None
                elif res.get('score') is not None:
                    s = res['score']
                    if s >= 70: row['Email status'] = 'verified (Hunter score %s)' % s; row['Confidence'] = 'high'
                    elif s >= 50: row['Email status'] = 'risky (Hunter score %s)' % s
                    else:
                        row['Email status'] = 'DEAD - do not use (Hunter %s)' % s
                        new_supp.append({'email': em, 'name': row['Full name'], 'company': row['Company'],
                                         'reason': f'hunter_score:{s}', 'date': time.strftime('%F'), 'source': '07_enrich'})
                    log(f'HU {em} -> score {s}')
            except Exception as e:
                log(f'HU error {em}: {e}')
    # Apollo pass (separate budget; spends precious free credits - default 0)
    if AP and a.apollo > 0:
        need = [r for r in rows if not r.get('LinkedIn URL') or not r.get('Work email') or r['Email status'].startswith('none')]
        for row in need[:a.apollo]:
            res = apollo_match(row, AP); ap_n += 1; time.sleep(1.5)
            if res.get('error'):
                log(f'Apollo: {res["error"]}'); 
                if 'RATELIMIT' in res['error'] or 'auth' in res['error']: break
                continue
            if res.get('email'): row['Work email'] = res['email']; row['Email status'] = res['email_status']; row['Email source'] = 'Apollo API'; row['Confidence'] = 'high'
            if res.get('linkedin'): row['LinkedIn URL'] = res['linkedin']
            if res.get('phone') and not row.get('Phone'): row['Phone'] = res['phone']; row['Phone type'] = res.get('phone_type'); row['Phone source'] = 'Apollo API'
            log(f'Apollo matched {row["Full name"]} @ {row["Company"]}')
    # write outputs
    json.dump(rows, open('leadgen/results/rows_enriched.json','w'), indent=1)
    cols = list(rows[0].keys())
    with open('leadgen/results/contacts_enriched.csv', 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.DictWriter(f, fieldnames=cols); w.writeheader(); w.writerows(rows)
    try:
        from openpyxl import Workbook
        wb = Workbook(); ws = wb.active; ws.title = 'Contacts (enriched)'; ws.append(cols)
        for r in rows: ws.append([r.get(c, '') for c in cols])
        ws.freeze_panes = 'A2'; ws.auto_filter.ref = ws.dimensions
        wb.save('leadgen/results/contacts_enriched.xlsx')
    except Exception as e: log(f'xlsx skip: {e}')
    if new_supp:
        exists = os.path.exists(supp_path)
        with open(supp_path, 'a', newline='', encoding='utf-8') as f:
            w = csv.DictWriter(f, fieldnames=['email', 'name', 'company', 'reason', 'date', 'source'])
            if not exists: w.writeheader()
            w.writerows(new_supp)
    log(f'DONE zb={zb_n} hunter={hu_n} apollo={ap_n} suppressed={len(new_supp)}')
    print(f'DONE. ZeroBounce used: {zb_n}, Hunter used: {hu_n}, Apollo used: {ap_n}, new suppressions: {len(new_supp)}')

if __name__ == '__main__': main()
