#!/usr/bin/env python3
"""Reverse-EDGAR discovery: newest SEC Form D filers (startups that just raised) ->
match to YC directory -> founder contacts + SEC officer names from the Form D XML itself.
A self-renewing, signal-based prospect source: companies with fresh money hire CoS."""
import requests, re, json, time, csv, os, sys
sys.path.insert(0, os.path.dirname(__file__))
from yc_parse import extract_company, slim

UA = {'User-Agent': 'IndividualJobSeeker research jobsearch.research@example.com', 'Accept': '*/*'}
S = requests.Session(); S.headers.update(UA)

import datetime
entries = []
d = datetime.date.today()
days = []
while len(days) < 6:
    if d.weekday() < 5: days.append(d)
    d -= datetime.timedelta(days=1)
for dd in days:
    q = f"QTR{(dd.month-1)//3+1}"
    url = f"https://www.sec.gov/Archives/edgar/daily-index/{dd.year}/{q}/master.{dd.strftime('%Y%m%d')}.idx"
    try:
        r = S.get(url, timeout=90)
    except Exception:
        continue
    if r.status_code != 200:
        continue
    n = 0
    for line in r.text.splitlines():
        p = line.split('|')
        if len(p) >= 5 and p[2].strip() == 'D':
            entries.append({'title': f"{p[1]} ({p[0]})", 'filed': dd.isoformat(),
                            'link': 'https://www.sec.gov/Archives/' + p[4].strip()})
            n += 1
    print(f"  {dd}: {n} Form D filings")
    time.sleep(0.4)
# dedupe by company
seen_c = set(); ded = []
for e in entries:
    if e['title'] in seen_c: continue
    seen_c.add(e['title']); ded.append(e)
entries = ded
print('recent Form D entries fetched:', len(entries))

sitemap = set(u.rstrip('/').split('/')[-1] for u in open('leadgen/data/yc_sitemap_urls.txt') if '/companies/' in u)
recs = [json.loads(l) for l in open('leadgen/data/companies_matched.jsonl')]
pool = {re.sub(r'[^a-z0-9]', '', r['name'].lower()): r for r in recs}

def slugify(n): return re.sub(r'[^a-z0-9]+', '-', (n or '').lower()).strip('-')
def norm(n): return re.sub(r'[^a-z0-9]', '', (n or '').lower())
CORP_SUFFIX = re.compile(r'(,?\s*(inc|llc|ltd|corp|corporation|lp|llp|plc|gmbh|technologies|technology|labs|lab|holdings|holding|group|systems|networks|ai)\.?\s*)+$', re.I)
def slug_candidates(name):
    clean = CORP_SUFFIX.sub('', (name or '').strip()).strip(' ,.')
    s = re.sub(r'[^a-z0-9\-]', '', re.sub(r'\s+', '-', clean.lower()))
    toks = [t for t in s.split('-') if t]
    out = {s}
    if toks: out.add(toks[0])
    if len(toks) > 1: out.add(f'{toks[0]}-{toks[1]}')
    return {o for o in out if o and len(o) > 2}

rows, yc_checked = [], 0
for e in entries:
    m = re.match(r'(?:\w+\s*-\s*)?(.+?)\s*\((?:0*|CIK=)?(\d+)\)', e['title'])
    comp = m.group(1).strip() if m else e['title'][:60]
    cik = m.group(2) if m else ''
    nn = norm(re.sub(r'\s*\(?.{0,3}(Inc|LLC|Ltd|Corp|Co|LP|LLP)\.?$', '', comp, flags=re.I))
    sl = slugify(re.sub(r'\s*[,\.]?\s*(Inc|LLC|Ltd|Corp|Co|LP|LLP)\.?$', '', comp, flags=re.I))
    match_yc = pool.get(nn, {}).get('slug', '')
    if not match_yc:
        for cand in slug_candidates(re.sub(r'\s*\(\d+\)\s*$', '', comp)):
            if cand in sitemap: match_yc = cand; break
    looks_fund = bool(re.search(r'(CAPITAL|FUND|PARTNERS|VENTURES|VENTURE|HOLDINGS|TRUST|ADVISOR|INVESTOR|MANAGEMENT|ASSOCIATES|\bL\.?P\.?\b|PRIVATE EQUITY|REALTY|PROPERTIES)', comp, re.I))
    row = {'company_as_filed': comp, 'cik': cik, 'form_d_filed': e['filed'][:10],
           'sec_link': e['link'], 'yc_slug': match_yc, 'founder': '', 'founder_title': '',
           'team_size': '', 'band': '', 'website': '', 'country': '', 'sec_officers': '',
           'note': 'likely fund/PE/RE issuer - not an employer target' if looks_fund and not match_yc else ''}
    if match_yc and yc_checked < 12:
        yc_checked += 1
        try:
            obj = extract_company(f'https://www.ycombinator.com/companies/{match_yc}')
            if obj:
                d = slim(obj)
                fs = [f for f in (d.get('founders') or []) if f.get('is_active')]
                if fs:
                    row['founder'] = fs[0].get('full_name') or ''; row['founder_title'] = fs[0].get('title') or ''
                row['team_size'] = d.get('team_size') or ''
                ts = d.get('team_size') or 0
                row['band'] = '11-50' if 11 <= ts <= 50 else ('51-200' if 51 <= ts <= 200 else ('201-500' if 201 <= ts <= 500 else ('1-10' if ts < 11 else '500+')))
                row['website'] = d.get('website') or ''; row['country'] = d.get('country') or ''
                if (d.get('ycdc_status') or '').lower() != 'active': row['note'] = f"YC status: {d.get('ycdc_status')}"
            time.sleep(0.4)
        except Exception as ex:
            row['note'] = f'yc fetch err {str(ex)[:50]}'
    # Form D XML -> related persons (officers/directors) for the most promising matches
    if match_yc and row['link'] and yc_checked <= 8:
        try:
            xr = S.get(row['link'], timeout=45)
            if xr.status_code == 200:
                people = re.findall(r'<relatedPerson>(.*?)</relatedPerson>', xr.text, re.S)
                offs = []
                for p in people[:6]:
                    fn = re.search(r'<firstName>(.*?)</firstName>', p); ln = re.search(r'<lastName>(.*?)</lastName>', p)
                    rel = re.search(r'<relationshipTitle>(.*?)</relationshipTitle>', p)
                    if fn and ln: offs.append(f"{fn.group(1)} {ln.group(1)} ({(rel.group(1) if rel else '').strip()[:40]})")
                row['sec_officers'] = ' | '.join(offs)
                time.sleep(0.4)
        except Exception:
            pass
    rows.append(row)

os.makedirs('leadgen/results', exist_ok=True)
with open('leadgen/results/funded_leads.csv', 'w', newline='', encoding='utf-8-sig') as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
n_yc = sum(1 for r in rows if r['yc_slug'])
n_band = sum(1 for r in rows if r['band'] in ('11-50','51-200','201-500'))
print(f'EDGAR DONE | filings listed: {len(rows)} | YC-matched: {n_yc} | in-band(11-500): {n_band}')
for r in rows:
    if r['yc_slug']: print(' MATCH:', r['company_as_filed'][:35], '| filed', r['form_d_filed'], '| founder:', r['founder'], '| band:', r['band'], '| officers:', r['sec_officers'][:70])
