import requests, re, html as H, json, sys

UA = {'User-Agent': 'Mozilla/5.0 (compatible; job-search-research/1.0)'}
DEC = json.JSONDecoder()

def extract_company(url, session=None):
    s = session or requests
    r = s.get(url, timeout=30, headers=UA)
    r.raise_for_status()
    h = H.unescape(r.text)
    # find the object that holds the company fields: locate '"team_size"' then walk back to enclosing '{'
    i = h.find('"team_size"')
    if i < 0: return None
    # scan backwards for the start of a JSON object containing it
    depth = 0; start = None
    for j in range(i, -1, -1):
        c = h[j]
        if c == '}': depth += 1
        elif c == '{':
            if depth == 0: start = j; break
            depth -= 1
    if start is None: return None
    try:
        obj, _ = DEC.raw_decode(h[start:])
    except Exception:
        return None
    return obj

def slim(obj):
    keep = ['name','slug','website','one_liner','long_description','batch','batch_name',
            'team_size','location','city','country','tags','ycdc_status','linkedin_url',
            'twitter_url','github_url','cb_url','year_founded']
    d = {k: obj.get(k) for k in keep}
    fnd = []
    for f in (obj.get('founders') or []):
        fnd.append({'full_name': f.get('full_name'), 'title': f.get('title'),
                    'is_active': f.get('is_active'), 'url': f.get('url'),
                    'user_id': f.get('user_id')})
    d['founders'] = fnd
    return d

if __name__ == '__main__':
    o = extract_company('https://www.ycombinator.com/companies/retool')
    d = slim(o)
    print(json.dumps(d, indent=1)[:2200])
