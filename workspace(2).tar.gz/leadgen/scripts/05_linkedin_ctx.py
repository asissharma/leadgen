import requests, re, json, html as H, time
from concurrent.futures import ThreadPoolExecutor, as_completed
UA={'User-Agent':'Mozilla/5.0 (compatible; job-search-research/1.0)'}
recs = {json.loads(l)['slug']: json.loads(l) for l in open('leadgen/data/people_target.jsonl')}
site = [json.loads(l) for l in open('leadgen/data/site_enrich.jsonl')]
out = {}
def work(s):
    slug = s['slug']
    if not s['linkedin_in']: return
    rec = recs[slug]; fn = (rec['best_founder']['full_name'] or '')
    parts = [p.lower() for p in fn.split() if len(p) > 2]
    hits = []
    for page in s['pages_fetched']:
        try:
            r = requests.get(page, timeout=12, headers=UA)
            if r.status_code >= 400: continue
            h = H.unescape(r.text)
            for m in re.finditer(r'https?://(?:[a-z]{2,3}\.)?linkedin\.com/in/[\w\-%]+', h, re.I):
                ctx = h[max(0,m.start()-350): m.end()+350].lower()
                score = sum(1 for p in parts if p in ctx)
                if score >= max(1, len(parts)-1) and len(parts) >= 2 or (score>=1 and len(parts)<2):
                    hits.append({'url': m.group(0).rstrip('/"\\'), 'page': page, 'name_match_parts': score})
            if hits: break
        except Exception: pass
        time.sleep(0.2)
    if hits: out[slug] = hits
targets = [s for s in site if s['linkedin_in']]
print('checking', len(targets), 'sites with /in/ links')
with ThreadPoolExecutor(max_workers=4) as ex:
    list(ex.map(work, targets))
json.dump(out, open('leadgen/data/linkedin_attributed.json','w'), indent=1)
for k,v in out.items(): print(k, '->', [x['url'] for x in v][:2])
print('attributed:', len(out))
