#!/usr/bin/env python3
"""Wayback email mining for email-gap rows (no-MX domains, DEAD fallbacks).
Archived /team /about /contact /press pages often retain emails removed from live sites.
If web.archive.org is unreachable from this sandbox, exits cleanly (runs fine in GitHub Actions)."""
import requests, re, json, time, sys, os
sys.path.insert(0, os.path.dirname(__file__))

UA = {'User-Agent': 'Mozilla/5.0 (job-search-research/1.0)'}
S = requests.Session(); S.headers.update(UA)
EMAIL_RE = re.compile(r'[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}')
IMG_EXT = re.compile(r'\.(png|jpe?g|webp|svg|gif|css|js|woff2?)(\.|$)', re.I)
GENERIC = {'info','hello','contact','support','sales','press','media','team','office','admin','help','careers','jobs','hr','privacy','legal','security','abuse','postmaster','noreply','no-reply','marketing','billing','mail','email'}

rows = json.load(open('leadgen/out/rows_enriched.json' if os.path.exists('leadgen/out/rows_enriched.json') else 'leadgen/results/rows_enriched.json'))
targets = [r for r in rows if (not r['Work email']) or r['Email status'].startswith('DEAD')]
print('email-gap targets:', len(targets))

# reachability probe
try:
    p = S.get('https://web.archive.org/cdx/search/cdx', params={'url': 'example.com', 'limit': '1'}, timeout=20)
    if p.status_code != 200: raise RuntimeError(f'HTTP {p.status_code}')
except Exception as e:
    print(f'web.archive.org unreachable from sandbox ({str(e)[:80]}). This step will run in GitHub Actions instead.')
    sys.exit(0)

def name_variants(full):
    t = [x for x in re.sub(r'[^\w\s]', ' ', full or '').split() if len(x) > 1]
    if not t: return set()
    first, last = t[0].lower(), t[-1].lower()
    v = {first, last, f'{first}.{last}', f'{first}{last}', f'{first[0]}{last}', f'{first[0]}.{last}', f'{first}_{last}', f'{last}.{first}'}
    return {re.sub(r'[._\-]', '', x) for x in v}

found = 0
for r in targets[:14]:
    dom = r['Company domain']
    if not dom: continue
    try:
        cdx = S.get('https://web.archive.org/cdx/search/cdx',
                    params={'url': f'{dom}/*', 'output': 'json', 'limit': '600', 'collapse': 'urlkey',
                            'filter': 'urlkey:.*(team|about|contact|press|imprint).*'}, timeout=40)
        snaps = cdx.json() if cdx.status_code == 200 else []
    except Exception as e:
        print(dom, 'cdx err', str(e)[:60]); continue
    picked = {}
    for row in snaps[1:]:
        ts, orig = row[1], row[2]
        if re.search(r'(team|about|contact|press)', orig, re.I) and orig.count('/') <= 4:
            key = orig.split('?')[0]
            if key not in picked or ts > picked[key]: picked[key] = ts
    hit_email = None
    for orig, ts in list(picked.items())[:3]:
        try:
            pr = S.get(f'https://web.archive.org/web/{ts}/{orig}', timeout=30)
            time.sleep(0.5)
        except Exception: continue
        if pr.status_code != 200: continue
        emails = {e.lower().strip('.') for e in EMAIL_RE.findall(pr.text) if not IMG_EXT.search(e)}
        nv = name_variants(r['Full name'])
        for e in emails:
            lp, d = e.split('@') if '@' in e else ('', '')
            if d.replace('www.', '') != dom and not d.endswith('.' + dom): continue
            if re.sub(r'[._\-]', '', lp) in nv:
                hit_email = e; break
        if hit_email: break
    if hit_email:
        found += 1
        r['Work email'] = hit_email
        r['Email status'] = 'unverified - found on archived company page (Wayback)'
        r['Email source'] = 'web.archive.org historical snapshot'
        r['Confidence'] = 'medium' if r['Confidence'] == 'low' else r['Confidence']
        r['Notes'] += f' | email recovered from archived page - verify before sending'
        print(f"  FOUND {r['Company']}: {hit_email}")
json.dump(rows, open('leadgen/results/rows_enriched.json', 'w'), indent=1)
print(f'WAYBACK DONE | recovered: {found}')
