#!/usr/bin/env python3
"""Radar v2: extend hiring-signal scan with Personio, Recruitee, SmartRecruiters,
Breezy, Teamtailor, JazzHR(applytojob), Workable + careers-page provider detection.
Merges into leadgen/data/hiring_signals.json (v1 results preserved)."""
import requests, re, json, time, html as H
from concurrent.futures import ThreadPoolExecutor, as_completed

UA = {'User-Agent': 'Mozilla/5.0 (compatible; job-search-research/1.0; individual jobseeker)'}
S = requests.Session(); S.headers.update(UA)
HOT = re.compile(r"(chief of staff|chief of ops|founder'?s? office|founding (team )?(operations|ops)|head of (business )?operations|strategy (&|and) ops|strategic operations|business operations|bizops|executive assistant to (the )?(ceo|founder)|chief of staff to the (ceo|founder))", re.I)
WARM = re.compile(r"(operations manager|ops manager|program manager|general manager|vp (of )?operations|director of operations|head of ops|founding|strategy|revenue operations|sales operations|people operations|operating)", re.I)

PROVIDER_RE = {
    'greenhouse': re.compile(r'(?:boards|jobs)\.greenhouse\.io/(?:embed/)?([\w\-]+)', re.I),
    'lever': re.compile(r'(?:jobs|apply)\.lever\.co/([\w\-]+)', re.I),
    'ashby': re.compile(r'(?:jobs|careers)\.ashbyhq\.com/([\w\-.]+)', re.I),
    'workable': re.compile(r'apply\.workable\.com/([\w\-]+)', re.I),
    'recruitee': re.compile(r'https?://([\w\-]+)\.recruitee\.com', re.I),
    'personio': re.compile(r'([\w\-]+)\.jobs\.personio\.(?:de|com|es|fr|co\.uk)', re.I),
    'breezy': re.compile(r'([\w\-]+)\.breezy\.hr', re.I),
    'smartrecruiters': re.compile(r'(?:careers|jobs|app)\.smartrecruiters\.com/([\w\-]+)', re.I),
    'teamtailor': re.compile(r'([\w\-]+)\.teamtailor\.com', re.I),
    'jazzhr': re.compile(r'([\w\-]+)\.applytojob\.com', re.I),
    'bamboo': re.compile(r'([\w\-]+)\.bamboohr\.com', re.I),
}

def get(url, **kw):
    try:
        r = S.get(url, timeout=12, **kw)
        return r if r.status_code == 200 else None
    except Exception:
        return None

def q_personio(slug):
    for tld in ('de', 'com'):
        r = get(f'https://{slug}.jobs.personio.{tld}/xml')
        if r and len(r.text) > 300:
            pos = re.findall(r'<position>(.*?)</position>', r.text, re.S)
            jobs = []
            for p in pos:
                m = re.search(r'<name>(?:<!\[CDATA\[)?(.*?)(?:\]\]>)?</name>', p, re.S)
                if m: jobs.append((H.unescape(m.group(1)).strip(), f'https://{slug}.jobs.personio.{tld}/'))
            if jobs: return jobs, f'personio:{slug}'
    return None, None

def q_recruitee(slug):
    r = get(f'https://{slug}.recruitee.com/api/offers/')
    if r:
        try:
            off = r.json().get('offers') or []
            if off: return [(o.get('title',''), f"https://{slug}.recruitee.com/o/{o.get('slug','')}") for o in off], f'recruitee:{slug}'
        except Exception: pass
    return None, None

def q_breezy(slug):
    r = get(f'https://{slug}.breezy.hr/json')
    if r:
        try:
            d = r.json()
            if isinstance(d, list) and d:
                return [(x.get('name') or x.get('title',''), f"https://{slug}.breezy.hr/apply/{x.get('friendly_id','')}") for x in d], f'breezy:{slug}'
        except Exception: pass
    return None, None

def q_smartrecruiters(org):
    r = get(f'https://api.smartrecruiters.com/v1/companies/{org}/postings?limit=100')
    if r:
        try:
            c = r.json().get('content') or []
            if c: return [(x.get('name',''), x.get('ref','')) for x in c], f'smartrecruiters:{org}'
        except Exception: pass
    return None, None

def q_teamtailor(slug):
    r = get(f'https://{slug}.teamtailor.com/jobs')
    if r:
        links = re.findall(r'href="([^"]*(?:/jobs/\d+-[^"]+))"', r.text)
        jobs = [(re.sub(r'[-\d]+', ' ', l.split('/jobs/')[-1]).replace('-', ' ').strip(), l if l.startswith('http') else f'https://{slug}.teamtailor.com{l}') for l in dict.fromkeys(links)]
        jobs = [(t, u) for t, u in jobs if t and len(t) > 3][:60]
        if jobs: return jobs, f'teamtailor:{slug}'
    return None, None

def q_jazzhr(slug):
    r = get(f'https://{slug}.applytojob.com/apply')
    if r:
        links = re.findall(r'href="([^"]*applytojob\.com/apply/[\w\-]+[^"]*)"[^>]*>([^<]{4,80})<', r.text)
        jobs = [(H.unescape(t).strip(), u) for u, t in dict.fromkeys([(u,t) for u,t in links])][:60]
        if jobs: return jobs, f'jazzhr:{slug}'
    return None, None

def q_workable(slug):
    try:
        r = S.post('https://apply.workable.com/api/v3/accounts/%s/jobs' % slug, json={}, timeout=12)
        if r.status_code == 200:
            res = r.json().get('results') or []
            if res: return [(x.get('title',''), f"https://apply.workable.com/{slug}/j/{x.get('shortcode','')}/") for x in res], f'workable:{slug}'
    except Exception: pass
    return None, None

QUERIES = {'personio': q_personio, 'recruitee': q_recruitee, 'breezy': q_breezy,
           'smartrecruiters': q_smartrecruiters, 'teamtailor': q_teamtailor,
           'jazzhr': q_jazzhr, 'workable': q_workable}

def slug_cands(rec):
    w = rec.get('website') or ''
    dn = re.sub(r'^https?://', '', w).split('/')[0]
    dn = re.sub(r'^www\.', '', dn).split('.')[0]
    nm = re.sub(r'[^a-z0-9]', '', (rec.get('name') or '').lower())
    out = []
    for b in (dn, rec['slug'], nm):
        if not b: continue
        for v in (b, 'try'+b, 'get'+b, 'use'+b, b+'hq', b+'app'):
            if v not in out: out.append(v)
    return out[:4]

def classify(jobs):
    hot, warm = [], []
    for t, u in jobs:
        if HOT.search(t): hot.append({'title': t, 'url': u})
        elif WARM.search(t): warm.append({'title': t, 'url': u})
    return hot, warm

def scan(rec, v1_entry):
    if v1_entry.get('hot_roles'):  # already actionable, save requests
        return None
    detected = {}
    pages = list(dict.fromkeys((v1_entry.get('careers_pages') or []) +
                ([rec['website']] if rec.get('website') else []) +
                [(rec.get('website') or '').rstrip('/') + p for p in ('/careers', '/jobs') if rec.get('website')]))
    for p in pages[:4]:
        if not p or not p.startswith('http'): continue
        r = get(p)
        time.sleep(0.15)
        if not r: continue
        h = H.unescape(r.text)
        for prov, rx in PROVIDER_RE.items():
            for m in rx.finditer(h):
                if m.groups() and m.group(1):
                    detected.setdefault(prov, set()).add(m.group(1).lower())
        if detected: break
    jobs, src = [], None
    for prov, slugs in detected.items():
        if prov in QUERIES:
            for sl in list(slugs)[:2]:
                j, s = QUERIES[prov](sl)
                if j: jobs, src = j, s; break
        elif prov == 'greenhouse':
            for sl in list(slugs)[:1]:
                r = get(f'https://boards-api.greenhouse.io/v1/boards/{sl}/jobs')
                if r:
                    try:
                        d = r.json().get('jobs') or []
                        if d: jobs, src = [(x.get('title',''), x.get('absolute_url','')) for x in d], f'greenhouse:{sl}'
                    except Exception: pass
        elif prov == 'lever':
            for sl in list(slugs)[:1]:
                r = get(f'https://api.lever.co/v0/postings/{sl}?mode=json')
                if r:
                    try:
                        d = r.json()
                        if isinstance(d, list) and d: jobs, src = [(x.get('text',''), x.get('hostedUrl') or x.get('applyUrl') or '') for x in d], f'lever:{sl}'
                    except Exception: pass
        elif prov == 'ashby':
            for sl in list(slugs)[:1]:
                r = get(f'https://api.ashbyhq.com/posting-api/job-board/{sl}')
                if r:
                    try:
                        d = (r.json() or {}).get('jobs') or []
                        if d: jobs, src = [(x.get('title',''), x.get('jobUrl') or x.get('applyUrl') or '') for x in d], f'ashby:{sl}'
                    except Exception: pass
        if jobs: break
    if not jobs:  # guessed slugs for new providers only
        cands = slug_cands(rec)
        for prov in ('personio', 'recruitee', 'breezy', 'workable', 'teamtailor'):
            for sl in cands[:3]:
                j, s = QUERIES[prov](sl)
                time.sleep(0.1)
                if j: jobs, src = j, s; break
            if jobs: break
    if not jobs and not detected:
        return None
    hot, warm = classify(jobs)
    upd = {'slug': rec['slug']}
    if src: upd['ats_v2'] = src
    if jobs: upd['n_open_roles_v2'] = len(jobs)
    if hot: upd['hot_roles'] = (v1_entry.get('hot_roles') or []) + hot
    if warm and not v1_entry.get('warm_roles'): upd['warm_roles'] = warm
    return upd if (src or hot or warm) else None

def main():
    sig = json.load(open('leadgen/data/hiring_signals.json'))
    by_slug = {s['slug']: s for s in sig['company_signals']}
    recs = [json.loads(l) for l in open('leadgen/data/people_target.jsonl')]
    updates, t0 = [], time.time()
    with ThreadPoolExecutor(max_workers=4) as ex:
        futs = {ex.submit(scan, r, by_slug.get(r['slug'], {})): r for r in recs}
        for i, f in enumerate(as_completed(futs), 1):
            u = f.result()
            if u: updates.append(u)
            if i % 25 == 0: print(f'{i}/{len(recs)} v2-scanned {time.time()-t0:.0f}s', flush=True)
    n_new_boards = n_new_hot = 0
    for u in updates:
        e = by_slug[u['slug']]
        if u.get('ats_v2') and not e.get('ats'): n_new_boards += 1
        if u.get('hot_roles') and not e.get('hot_roles'):
            n_new_hot += 1
            print('NEW HOT:', e['company'], '->', [x['title'] for x in u['hot_roles']][:3], f"({u.get('ats_v2')})")
        for k, v in u.items():
            if k != 'slug': e[k] = v
        if u.get('ats_v2') and not e.get('ats'): e['ats'] = u['ats_v2']
        if u.get('n_open_roles_v2') and not e.get('n_open_roles'): e['n_open_roles'] = u['n_open_roles_v2']
    json.dump(sig, open('leadgen/data/hiring_signals.json', 'w'), indent=1)
    print(f'RADAR v2 DONE {time.time()-t0:.0f}s | updates={len(updates)} new_boards={n_new_boards} new_hot={n_new_hot}')

if __name__ == '__main__':
    main()
