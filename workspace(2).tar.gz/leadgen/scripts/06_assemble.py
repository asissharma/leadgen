import json, re, csv, unicodedata
from datetime import date

TODAY = '2026-10-01'
recs = [json.loads(l) for l in open('leadgen/data/people_target.jsonl')]
site = {json.loads(l)['slug']: json.loads(l) for l in open('leadgen/data/site_enrich.jsonl')}
ghmx = json.load(open('leadgen/data/gh_mx.json'))
gh, mx = ghmx['github'], ghmx['mx']
li_attr = json.load(open('leadgen/data/linkedin_attributed.json'))
# from licensed web_search (2026-10-01)
li_search = {
 'zip':'https://www.linkedin.com/in/rujulz',
 'beu-delivery':'https://et.linkedin.com/in/hao-zheng-746425211',
 'fazz':'https://www.linkedin.com/in/hendra-kwik-9559612ba',
 'rose-rocket':'https://ca.linkedin.com/in/luksidadi',
 'mindee':'https://www.linkedin.com/in/jonathan-grandperrin-47014563',
 'encord':'https://www.linkedin.com/in/ulrik-stig-hansen-2658273b',
}
EXCLUDE_SLUGS = {'marketforce': 'Founder left company Sep 2023 per public LinkedIn snippet (YC data stale) - recency exclusion'}
RECENCY_NOTES = {'snapdocs': 'Per 2023 company announcement Aaron King moved to Executive Chairman (still founder); verify current title before outreach'}
GENERIC_LOCALS = {'info','hello','contact','support','sales','press','media','team','office','admin','help','careers','jobs','hr','privacy','legal','security','abuse','postmaster','noreply','no-reply','marketing','partnerships','bd','billing','accounts','reception','mail','email','enquiries','inquiries','general','service','services','customerservice','newbusiness','hello-berlin'}
EU = set('AT BE BG HR CY CZ DK EE FI FR DE GR HU IE IT LV LT LU MT NL PL PT RO SK SI ES IS LI NO'.split())
def flag(country):
    c = (country or '').upper()
    if c == 'GB': return 'UK-GDPR'
    if c in EU: return 'GDPR-EU'
    if c == 'CH': return 'FADP-CH'
    if c == 'CA': return 'CASL-CA'
    if c == 'US': return 'CAN-SPAM/TCPA-US'
    if c == 'BR': return 'LGPD-BR'
    return f'local-law-{c}' if c else 'unknown'
def strip_acc(s):
    return ''.join(c for c in unicodedata.normalize('NFKD', s) if not unicodedata.combining(c))
def parts(full):
    t = [x for x in strip_acc(re.sub(r'[^\w\s]', ' ', full or '')).split() if len(x) > 1]
    if not t: return '', ''
    return t[0].lower(), t[-1].lower()

rows, excluded = [], []
seen = set()
for rec in recs:
    slug = rec['slug']
    if slug in EXCLUDE_SLUGS:
        excluded.append((rec['best_founder']['full_name'], rec['name'], EXCLUDE_SLUGS[slug])); continue
    s = site.get(slug, {})
    dom = s.get('domain') or ''
    fn = rec['best_founder']['full_name'] or ''
    title_extra = ''
    if ',' in fn:
        fn, title_extra = [x.strip() for x in fn.split(',', 1)]
    first, last = parts(fn)
    key = (fn.lower(), dom)
    if key in seen: continue
    seen.add(key)
    notes = []
    other = []
    if rec.get('linkedin_url'): other.append(f"Company LinkedIn: {rec['linkedin_url']}")
    for x in (s.get('x_links') or [])[:2]: other.append(f"X: {x}")
    same_dom = s.get('same_domain_emails') or []
    generic = [e for e in same_dom if e.split('@')[0] in GENERIC_LOCALS]
    personal_site = [e for e in same_dom if e.split('@')[0] not in GENERIC_LOCALS and e not in (s.get('attributed_emails') or [])]
    for e in list(dict.fromkeys(generic))[:2]: other.append(f"Role email: {e}")
    if rec.get('website'): other.append(f"Website: {rec['website']}")
    other.append(f"YC page: https://www.ycombinator.com/companies/{slug}")

    email, status, esource, conf = '', '', '', 'low'
    # 1) attributed from company site
    if s.get('attributed_emails'):
        email = s['attributed_emails'][0]; status = 'unverified - found on company website'; esource = 'company website (public)'
        conf = 'high'; notes.append('email published on company site; SMTP verification pending (Hunter free key)')
    # 2) github founder hit
    elif gh.get(slug, {}).get('founder_hits'):
        email = gh[slug]['founder_hits'][0]['email']; status = 'unverified - public GitHub commit'; esource = 'github public commit metadata'
        conf = 'high'; notes.append('from public git commit author metadata')
    else:
        pattern, psrc = None, None
        g = gh.get(slug) or {}
        if g.get('pattern'): pattern, psrc = g['pattern'], 'github team commits'
        elif personal_site:
            lp = personal_site[0].split('@')[0]
            # crude pattern detection vs unknown name: check dot structure
            pattern = 'first.last' if '.' in lp else ('firstlast' if len(lp) > 3 else None)
            psrc = 'team email on company site'
        has_mx = bool(mx.get(dom))
        if not has_mx and dom:
            status = 'none - domain has no MX records'; notes.append('no mail servers on domain; do not infer email')
        else:
            if pattern in ('first.last','first_last','first-last'): cand = f'{first}.{last}@{dom}'
            elif pattern == 'firstlast': cand = f'{first}{last}@{dom}'
            elif pattern == 'first': cand = f'{first}@{dom}'
            elif pattern == 'flast': cand = f'{first[0]}{last}@{dom}'
            else:
                cand = (f'{first}@{dom}' if rec['band'] == '11-50' else f'{first}.{last}@{dom}')
                psrc = 'industry convention for headcount band'
            if first and last and dom:
                email = cand
                if psrc and 'convention' not in psrc:
                    status = 'unverified - inferred (real domain pattern)'; conf = 'medium'
                    notes.append(f'pattern {pattern} observed in {psrc}')
                else:
                    status = 'unverified - inferred (convention)'; conf = 'low'
                    alt = f'{first}.{last}@{dom}' if rec['band'] == '11-50' else f'{first}@{dom}'
                    notes.append(f'convention guess (MX present); alternate pattern: {alt}')
            else:
                status = 'none - name not parseable'
    # linkedin
    li = li_search.get(slug, '')
    if not li and slug in li_attr:
        best = max(li_attr[slug], key=lambda h: h.get('name_match_parts', 0))
        li = best['url']
        notes.append('LinkedIn from company website (name-context matched)')
    if slug in RECENCY_NOTES: notes.append(RECENCY_NOTES[slug])
    # phone (with sanity filter)
    def phone_ok(p):
        d = re.sub(r'\D', '', p)
        if not (9 <= len(d) <= 15): return False
        if p.strip().startswith('+0') or p.strip().startswith('+99'): return False
        if re.match(r'^\+1[01]', p.strip()): return False
        if re.search(r'(1234567|1238888|8888888|0000000)', d): return False
        return True
    def phone_type(p, country):
        d = re.sub(r'\D', '', p)
        if d.startswith('65') and len(d) == 10 and d[2] in '89': return 'mobile (listed on site)'
        if d.startswith('91') and len(d) == 12 and d[2] in '789': return 'mobile (listed on site)'
        if p.strip().startswith('+1') and d.startswith('1') and d[1:4] in ('833','844','855','866','877','888'): return 'toll-free main line'
        return 'main line'
    phone, ptype, psource = '', '', ''
    cand_phones = [p for p in (s.get('phones') or []) if phone_ok(p['phone'])]
    if cand_phones:
        ph = sorted(cand_phones, key=lambda p: 0 if re.search(r'contact|imprint|kontakt', p.get('page',''), re.I) else 1)[0]
        phone, psource = ph['phone'], f"company website ({ph.get('page','')[:60]})"
        ptype = phone_type(ph['phone'], rec.get('country'))
    # confidence bump
    if conf != 'high' and (li or phone) and email: conf = 'medium' if conf == 'low' else conf
    if conf == 'high' and not email: conf = 'medium'
    if title_extra: notes.append(f'YC profile also lists: {title_extra}')
    rows.append({
        'Full name': fn, 'Title': rec['best_founder'].get('title') or '', 'Company': rec['name'],
        'Company domain': dom, 'Headcount band': rec['band'], 'Industry': ', '.join(rec.get('tags') or []),
        'Country/City': f"{rec.get('country') or ''}{' / ' + rec['city'] if rec.get('city') else ''}",
        'LinkedIn URL': li, 'Work email': email, 'Email status': status, 'Email source': esource or (psrc if email else ''),
        'Phone': phone, 'Phone type': ptype, 'Phone source': psource,
        'Other channels': ' | '.join(other), 'Confidence': conf, 'Date collected': TODAY,
        'Notes': f"[{flag(rec.get('country'))}] " + '; '.join(notes) + (f" | YC {rec.get('batch','')}" if rec.get('batch') else ''),
    })

cols = ['Full name','Title','Company','Company domain','Headcount band','Industry','Country/City','LinkedIn URL','Work email','Email status','Email source','Phone','Phone type','Phone source','Other channels','Confidence','Date collected','Notes']
rows.sort(key=lambda r: ({'high':0,'medium':1,'low':2}[r['Confidence']], r['Company']))
with open('leadgen/results/contacts.csv','w',newline='',encoding='utf-8-sig') as f:
    w = csv.DictWriter(f, fieldnames=cols); w.writeheader(); w.writerows(rows)

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter
wb = Workbook(); ws = wb.active; ws.title = 'Contacts'
ws.append(cols)
hf = PatternFill('solid', fgColor='1F4E79')
for c in ws[1]: c.font = Font(bold=True, color='FFFFFF'); c.fill = hf; c.alignment = Alignment(vertical='center')
conf_fill = {'high': PatternFill('solid', fgColor='C6EFCE'), 'medium': PatternFill('solid', fgColor='FFEB9C'), 'low': PatternFill('solid', fgColor='FFC7CE')}
for r in rows:
    ws.append([r[c] for c in cols])
    ws.cell(ws.max_row, cols.index('Confidence')+1).fill = conf_fill.get(r['Confidence'], PatternFill())
widths = [22,20,18,18,13,22,16,38,32,30,26,18,10,30,50,11,12,60]
for i,wd in enumerate(widths,1): ws.column_dimensions[get_column_letter(i)].width = wd
ws.freeze_panes = 'A2'; ws.auto_filter.ref = ws.dimensions
ws2 = wb.create_sheet('Excluded & audit')
ws2.append(['Name','Company','Reason']); 
for e in excluded: ws2.append(list(e))
ws2.append([]); ws2.append(['Generated', TODAY, 'Pipeline: YC sitemap -> company pages -> website mining -> GitHub -> MX -> inference'])
wb.save('leadgen/results/contacts.xlsx')

from collections import Counter
print('ROWS:', len(rows))
print('email coverage:', sum(1 for r in rows if r['Work email']), '/', len(rows))
print('email by status:', Counter(r['Email status'].split(' - ')[0] + ('-' + r['Email status'].split('(')[-1].rstrip(')') if 'inferred' in r['Email status'] else '') for r in rows))
print('phone coverage:', sum(1 for r in rows if r['Phone']), '/', len(rows))
print('linkedin coverage:', sum(1 for r in rows if r['LinkedIn URL']), '/', len(rows))
print('confidence:', Counter(r['Confidence'] for r in rows))
print('excluded:', excluded)
json.dump(rows, open('leadgen/results/rows.json','w'), indent=1)
