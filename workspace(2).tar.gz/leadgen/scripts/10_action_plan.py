#!/usr/bin/env python3
"""Merge hiring signals into contacts -> Priority tiers, Action Plan tracker sheet, hot_targets.csv"""
import json, csv, re
rows = json.load(open('leadgen/results/rows_enriched.json'))
sig = json.load(open('leadgen/data/hiring_signals.json'))
S = {s['slug']: s for s in sig['company_signals']}
slug_by_company = {r['Company']: None for r in rows}
recs = [json.loads(l) for l in open('leadgen/data/people_target.jsonl')]
comp2slug = {r['name']: r['slug'] for r in recs}

for r in rows:
    s = S.get(comp2slug.get(r['Company'], ''), {})
    r['_sig'] = s
    # idempotency: strip previously appended signal text
    r['Notes'] = re.sub(r'\s*\|\|\s*(HIRING SIGNAL|ops signal).*$', '', r.get('Notes') or '')
    if s.get('hot_roles'): r['Priority'] = 'P0 - HIRING NOW (CoS/FounderOffice role open)'
    elif s.get('warm_roles'): r['Priority'] = 'P1 - ops hiring (create-the-role pitch)'
    elif s.get('ats') or s.get('careers_pages'): r['Priority'] = 'P2 - hiring, no matching role yet'
    else: r['Priority'] = 'P3 - no signal (monitor)'
    if s.get('hot_roles'):
        hr = s['hot_roles'][0]
        r['Notes'] += f" || HIRING SIGNAL 2026-10-01: '{hr['title']}' open -> {hr['url']}"
    elif s.get('warm_roles'):
        wr = s['warm_roles'][0]
        r['Notes'] += f" || ops signal 2026-10-01: '{wr['title']}' open -> {wr['url']}"

json.dump(rows, open('leadgen/results/rows_enriched.json','w'), indent=1)

order = {'P0':0,'P1':1,'P2':2,'P3':3}
def sort_key(r):
    band_boost = 0 if r['Headcount band'] in ('51-200','201-500') else 1
    ver = 0 if r['Email status'].startswith('verified') else (1 if r['Work email'] else 2)
    return (order[r['Priority'][:2]], band_boost, ver, r['Company'])
rows.sort(key=sort_key)

# ---- hot_targets.csv (P0+P1 action list) ----
hcols = ['Priority','Company','Founder','Title','Open role (signal)','Apply URL','Work email','Email status','LinkedIn URL','Phone','Headcount band','Country/City','Company domain','Compliance flag','Stage','Date sent','Follow-up date','Reply?']
def flag_of(notes):
    m = re.match(r'\[([^\]]+)\]', notes or '')
    return m.group(1) if m else ''
hot = []
for r in rows:
    if not r['Priority'].startswith(('P0','P1')): continue
    s = r['_sig']
    roles = s.get('hot_roles') or s.get('warm_roles') or []
    hot.append({'Priority': r['Priority'], 'Company': r['Company'], 'Founder': r['Full name'], 'Title': r['Title'],
        'Open role (signal)': ' ; '.join(x['title'] for x in roles[:3]), 'Apply URL': roles[0]['url'] if roles else '',
        'Work email': r['Work email'], 'Email status': r['Email status'], 'LinkedIn URL': r['LinkedIn URL'],
        'Phone': r['Phone'], 'Headcount band': r['Headcount band'], 'Country/City': r['Country/City'],
        'Company domain': r['Company domain'], 'Compliance flag': flag_of(r['Notes']),
        'Stage': 'To-contact', 'Date sent': '', 'Follow-up date': '', 'Reply?': ''})
with open('leadgen/results/hot_targets.csv','w',newline='',encoding='utf-8-sig') as f:
    w = csv.DictWriter(f, fieldnames=hcols); w.writeheader(); w.writerows(hot)

# ---- rebuild xlsx with all sheets ----
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter
cols = ['Full name','Title','Company','Company domain','Headcount band','Industry','Country/City','LinkedIn URL','Work email','Email status','Email source','Phone','Phone type','Phone source','Other channels','Confidence','Date collected','Notes']
pri_fill = {'P0': PatternFill('solid', fgColor='FF6B6B'), 'P1': PatternFill('solid', fgColor='FFD93D'), 'P2': PatternFill('solid', fgColor='B8E0D2'), 'P3': PatternFill('solid', fgColor='E8E8E8')}
conf_fill = {'high': PatternFill('solid', fgColor='C6EFCE'), 'medium': PatternFill('solid', fgColor='FFEB9C'), 'low': PatternFill('solid', fgColor='FFC7CE')}
wb = Workbook()

ws = wb.active; ws.title = 'Action Plan'
ws.append(['Priority','Company','Founder','Title','Signal role','Apply URL','Work email','Email status','LinkedIn','Phone','Band','Country/City','Stage','Date sent','Follow-up','Reply?','Notes (first 120ch)'])
for c in ws[1]: c.font = Font(bold=True, color='FFFFFF'); c.fill = PatternFill('solid', fgColor='1F4E79')
for r in rows:
    s = r['_sig']; roles = (s.get('hot_roles') or s.get('warm_roles') or [])
    ws.append([r['Priority'], r['Company'], r['Full name'], r['Title'], roles[0]['title'] if roles else '', roles[0]['url'] if roles else '',
               r['Work email'], r['Email status'], r['LinkedIn URL'], r['Phone'], r['Headcount band'], r['Country/City'],
               'To-contact','','','', r['Notes'][:120]])
    ws.cell(ws.max_row, 1).fill = pri_fill.get(r['Priority'][:2], PatternFill())
for i,wd in enumerate([34,16,20,16,30,42,30,30,36,16,10,14,11,10,11,8,60],1): ws.column_dimensions[get_column_letter(i)].width = wd
ws.freeze_panes = 'A2'; ws.auto_filter.ref = ws.dimensions

ws2 = wb.create_sheet('Contacts (schema)')
ws2.append(cols)
for c in ws2[1]: c.font = Font(bold=True, color='FFFFFF'); c.fill = PatternFill('solid', fgColor='1F4E79')
for r in rows:
    ws2.append([r.get(c,'') for c in cols])
    ws2.cell(ws2.max_row, cols.index('Confidence')+1).fill = conf_fill.get(r['Confidence'], PatternFill())
for i,wd in enumerate([22,20,18,18,13,22,16,38,32,34,26,18,20,30,50,11,12,80],1): ws2.column_dimensions[get_column_letter(i)].width = wd
ws2.freeze_panes = 'A2'; ws2.auto_filter.ref = ws2.dimensions

ws3 = wb.create_sheet('Hiring Signals')
ws3.append(['Company','ATS board','Total open roles','HOT roles (CoS/FounderOffice)','WARM roles (ops/strategy)','Careers pages'])
for c in ws3[1]: c.font = Font(bold=True, color='FFFFFF'); c.fill = PatternFill('solid', fgColor='1F4E79')
for s in sorted(sig['company_signals'], key=lambda x: -(len(x['hot_roles'])*10 + len(x['warm_roles']))):
    if not (s['ats'] or s['hot_roles'] or s['warm_roles'] or s['careers_pages']): continue
    ws3.append([s['company'], s['ats'] or '', s['n_open_roles'],
                ' | '.join(f"{x['title']} {x['url']}" for x in s['hot_roles'][:4]),
                ' | '.join(f"{x['title']}" for x in s['warm_roles'][:4]),
                ' | '.join(s['careers_pages'][:1])])
for i,wd in enumerate([20,18,10,70,60,40],1): ws3.column_dimensions[get_column_letter(i)].width = wd
ws3.freeze_panes = 'A2'

ws4 = wb.create_sheet('Verification log')
from collections import Counter
c = Counter()
for r in rows:
    st = r['Email status']
    if st.startswith('verified ('): c['verified (SMTP-valid, non-catch-all)'] += 1
    elif st.startswith('verified*'): c['verified* (valid, catch-all domain)'] += 1
    elif st.startswith('DEAD'): c['DEAD - suppressed'] += 1
    elif st.startswith('none'): c['no email (domain has no MX)'] += 1
    elif 'real domain pattern' in st: c['inferred from real domain pattern'] += 1
    elif 'convention' in st: c['inferred from convention'] += 1
for k,v in c.most_common(): ws4.append([k,v])
ws4.append([])
ws4.append(['Priorities', str(dict(Counter(r['Priority'][:2] for r in rows)))])

ws5 = wb.create_sheet('Excluded & audit')
ws5.append(['Name','Company','Reason'])
ws5.append(['Mesongo Sibuti','MarketForce','Founder left company Sep 2023 (public LinkedIn snippet) - recency exclusion'])
ws5.append(['HN scan 2026-10-01','Legion Health / MixRank','No CoS openings in last 5 months threads - monitor monthly'])
wb.save('leadgen/results/contacts_enriched.xlsx')

print('rebuilt xlsx. priorities:', Counter(r['Priority'][:2] for r in rows))
print('hot_targets.csv rows:', len(hot))
for h in hot: print(' ', h['Priority'][:2], '|', h['Company'][:18], '|', h['Founder'][:20], '|', h['Open role (signal)'][:44], '| email:', h['Work email'][:30] or '(none)', '| li:', 'Y' if h['LinkedIn URL'] else '-')
