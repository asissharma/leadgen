import requests, re, json, time, random, sys, os
from concurrent.futures import ThreadPoolExecutor, as_completed
sys.path.insert(0, os.path.dirname(__file__))
from yc_parse import extract_company, slim, UA

URLS = [u.strip() for u in open('leadgen/data/yc_sitemap_urls.txt') if u.strip()]
URLS = [u for u in URLS if '/companies/industry/' not in u]
SKIP_SLUGS = {'black-founders','hispanic-latino-founders','women-founders','founders-you-may-know','sitemap'}
URLS = [u for u in URLS if u.rstrip('/').split('/')[-1] not in SKIP_SLUGS]
random.seed(A.seed); random.shuffle(URLS)

import argparse
ap = argparse.ArgumentParser()
ap.add_argument('--include', default=r'\b(founder|co-?founder|ceo|chief executive|managing director)\b')
ap.add_argument('--exclude', default=r'(freelance|stealth|self[\s-]?employ|part[\s-]?time|independent)')
ap.add_argument('--target', type=int, default=140)
ap.add_argument('--max-fetch', type=int, default=650)
ap.add_argument('--seed', type=int, default=42)
A = ap.parse_args()
INCLUDE = re.compile(A.include, re.I)
EXCLUDE = re.compile(A.exclude, re.I)

def band(n):
    if n is None: return None
    if 11 <= n <= 50: return '11-50'
    if 51 <= n <= 200: return '51-200'
    if 201 <= n <= 500: return '201-500'
    return None

TARGET = A.target
MAX_FETCH = A.max_fetch
results, fetched, errors = [], 0, 0
lock_free_list = []

def work(url):
    global fetched, errors
    try:
        obj = extract_company(url)
        return url, obj, None
    except Exception as e:
        return url, None, str(e)[:120]

sess = requests.Session()
sess.headers.update(UA)
t0 = time.time()
batch_iter = iter(URLS[:MAX_FETCH])
pending = set()

with ThreadPoolExecutor(max_workers=3) as ex:
    def refill():
        while len(pending) < 6 and len(results) + len(pending) < MAX_FETCH:
            try: pending.add(ex.submit(work, next(batch_iter)))
            except StopIteration: break
    refill()
    while pending and len(results) < TARGET:
        done = next(as_completed(pending)); pending.discard(done)
        url, obj, err = done.result()
        fetched += 1
        if err: errors += 1
        elif obj:
            d = slim(obj)
            b = band(d.get('team_size'))
            status = (d.get('ycdc_status') or '')
            keep_founders = []
            for f in d.get('founders') or []:
                t = f.get('title') or ''
                bio = f.get('founder_bio') or ''
                if not f.get('is_active', True): continue
                if EXCLUDE.search(t) or EXCLUDE.search(bio): continue
                if INCLUDE.search(t): keep_founders.append(f)
            if b and status.lower() == 'active' and keep_founders:
                d['band'] = b; d['matched_founders'] = keep_founders; d['source_url'] = url
                results.append(d)
        refill()
        if fetched % 50 == 0:
            print(f'fetched={fetched} matched={len(results)} errors={errors} elapsed={time.time()-t0:.0f}s', flush=True)
        time.sleep(0.25)

os.makedirs('leadgen/data/companies', exist_ok=True)
with open('leadgen/data/companies_matched.jsonl','w') as f:
    for d in results: f.write(json.dumps(d)+'\n')

from collections import Counter
print('DONE fetched=', fetched, 'matched companies=', len(results), 'errors=', errors, 'time=', f'{time.time()-t0:.0f}s')
print('bands:', Counter(d['band'] for d in results))
print('countries:', Counter(d.get('country') or '?' for d in results).most_common(12))
print('founders total:', sum(len(d['matched_founders']) for d in results))
