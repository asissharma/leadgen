#!/usr/bin/env python3
"""CoS job-feed monitor: Remotive, RemoteOK, Himalayas, WorkingNomads, TheMuse, HN Algolia
(+ Adzuna/Jooble when env keys present). Matches hits against our pool; unmatched companies
get reverse-lookup via the YC sitemap -> founder contacts -> new P0 candidates."""
import requests, re, json, time, os, html as H, sys
sys.path.insert(0, os.path.dirname(__file__))

UA = {'User-Agent': 'Mozilla/5.0 (compatible; job-search-research/1.0; individual jobseeker)', 'Accept': '*/*'}
S = requests.Session(); S.headers.update(UA)
HOT = re.compile(r"(chief of staff|chief of ops|founder'?s? office|founding (team )?(operations|ops)|head of (business )?operations|strategy (&|and) ops|strategic operations|business operations|bizops|executive assistant to (the )?(ceo|founder)|founders associate|associate to the (ceo|founder))", re.I)
WARM = re.compile(r"(operations manager|ops manager|program manager|general manager|vp (of )?operations|director of operations|head of ops|revenue operations|sales operations|people operations)", re.I)

feeds_out, errors = [], []
def add(source, company, title, url, location='', email='', extra=''):
    lvl = 'HOT' if HOT.search(title or '') else ('WARM' if WARM.search(title or '') else '')
    if lvl:
        feeds_out.append({'source': source, 'level': lvl, 'company': company or '', 'title': title or '',
                          'url': url or '', 'location': location or '', 'email_in_posting': email or '', 'extra': extra})

def safe(name, fn):
    try: fn()
    except Exception as e: errors.append(f'{name}: {str(e)[:100]}')

def remotive():
    r = S.get('https://remotive.com/api/remote-jobs', timeout=40)
    for j in r.json().get('jobs', []):
        add('remotive', j.get('company_name'), j.get('title'), j.get('url'), j.get('candidate_required_location',''), '', j.get('tags',[''])[0] if j.get('tags') else '')
    print('remotive:', len(r.json().get('jobs', [])), 'jobs scanned')

def remoteok():
    r = S.get('https://remoteok.com/api', timeout=30, headers={'Accept':'application/json'})
    if r.status_code != 200: errors.append(f'remoteok: HTTP {r.status_code}'); return
    d = r.json()
    for j in d[1:] if isinstance(d, list) else []:
        add('remoteok', j.get('company'), j.get('position'), j.get('url') or j.get('apply_url'), j.get('location',''), j.get('email',''))
    print('remoteok:', max(0, len(d)-1), 'jobs scanned')

def himalayas():
    r = S.get('https://himalayas.app/jobs/api', timeout=30)
    if r.status_code != 200: errors.append(f'himalayas: HTTP {r.status_code}'); return
    for j in r.json().get('jobs', []):
        add('himalayas', (j.get('company') or {}).get('name'), j.get('title'), j.get('externalUrl') or j.get('url',''), (j.get('location') or ''))
    print('himalayas:', len(r.json().get('jobs', [])), 'jobs scanned')

def workingnomads():
    r = S.get('https://www.workingnomads.com/api/exposed_jobs/', timeout=30)
    if r.status_code != 200: errors.append(f'wnomads: HTTP {r.status_code}'); return
    for j in r.json() if isinstance(r.json(), list) else []:
        add('workingnomads', j.get('company_name'), j.get('title'), j.get('url'), j.get('location',''))
    print('workingnomads:', len(r.json()), 'jobs scanned')

def themuse():
    for page in (1, 2):
        r = S.get('https://www.themuse.com/api/public/jobs', params={'page': page}, timeout=25)
        if r.status_code != 200: errors.append(f'themuse: HTTP {r.status_code}'); return
        for j in r.json().get('results', []):
            add('themuse', (j.get('company') or {}).get('name'), j.get('name'), (j.get('refs') or {}).get('landing_page',''), (j.get('location') or ''))
        time.sleep(0.5)
    print('themuse: 2 pages scanned')

def hn():
    for q in ('"chief of staff"', '"founding operations"', '"founder\'s office"', '"head of operations"'):
        r = S.get('https://hn.algolia.com/api/v1/search_by_date',
                  params={'query': q, 'tags': 'comment', 'hitsPerPage': 30,
                          'numericFilters': f'created_at_i>{int(time.time())-45*86400}'}, timeout=25)
        for hit in r.json().get('hits', []):
            txt = H.unescape(re.sub(r'<[^>]+>', ' ', hit.get('comment_text') or ''))
            if not re.search(r"(we.re hiring|who is hiring|is hiring|are hiring|join (us|our) team|hiring for)", txt, re.I): continue
            if re.search(r"(i am|im|i.m) (a |an )?(founder|operator|engineer|looking)|looking for (a|an) (chief|cos|operations|ops) role", txt, re.I): continue
            m = HOT.search(txt)
            if m:
                em = re.findall(r'[\w.\-]+@[\w.\-]+\.\w{2,}', txt)
                co = re.search(r'([A-Z][\w&.\-]{2,40})\s*\(YC', txt)
                add('hn-whos-hiring', co.group(1) if co else '(see snippet)', m.group(0),
                    f"https://news.ycombinator.com/item?id={hit.get('objectID')}", '', em[0] if em else '', txt[:200])
        time.sleep(1)
    print('hn: scanned')

def adzuna():
    aid, akey = os.getenv('ADZUNA_APP_ID'), os.getenv('ADZUNA_API_KEY')
    if not (aid and akey): print('adzuna: no key (free: developer.adzuna.com) - skipped'); return
    for ctry in ('us', 'gb', 'de'):
        r = S.get(f'https://api.adzuna.com/v1/search/live/1/{ctry}',
                  params={'app_id': aid, 'app_key': akey, 'what': 'chief of staff', 'results_per_page': 50}, timeout=25)
        if r.status_code == 200:
            for j in r.json().get('results', []):
                add(f'adzuna-{ctry}', (j.get('company') or {}).get('display_name'), j.get('title'), j.get('redirect_url'), j.get('location',{}).get('display_name',''))
        time.sleep(0.5)
    print('adzuna: done')

def jooble():
    jk = os.getenv('JOOBLE_API_KEY')
    if not jk: print('jooble: no key (free: jooble.org/api/about) - skipped'); return
    r = S.post(f'https://jooble.org/api/{jk}', json={'keywords': 'chief of staff startup', 'page': 1}, timeout=25)
    if r.status_code == 200:
        for j in r.json().get('jobs', []):
            add('jooble', j.get('company'), j.get('title'), j.get('link'), j.get('location',''))
    print('jooble: done')

for name, fn in [('remotive', remotive), ('remoteok', remoteok), ('himalayas', himalayas),
                 ('workingnomads', workingnomads), ('themuse', themuse), ('hn', hn),
                 ('adzuna', adzuna), ('jooble', jooble)]:
    safe(name, fn)

# --- dedupe ---
seen = set(); uniq = []
for j in feeds_out:
    k = (j['company'].lower().strip(), j['title'].lower().strip()[:40])
    if k in seen: continue
    seen.add(k); uniq.append(j)
feeds_out = uniq

# --- match against our pool ---
recs = [json.loads(l) for l in open('leadgen/data/people_target.jsonl')]
allrecs = [json.loads(l) for l in open('leadgen/data/companies_matched.jsonl')]
pool_names = {}
for r in allrecs:
    pool_names[re.sub(r'[^a-z0-9]', '', r['name'].lower())] = r['slug']
sitemap = set(u.rstrip('/').split('/')[-1] for u in open('leadgen/data/yc_sitemap_urls.txt') if '/companies/' in u)

def norm(n): return re.sub(r'[^a-z0-9]', '', (n or '').lower())
def slugify(n):
    s = re.sub(r'[^a-z0-9]+', '-', (n or '').lower()).strip('-')
    return s

new_cos = []
for j in feeds_out:
    nn = norm(j['company'])
    j['pool_match'] = pool_names.get(nn, '')
    if not j['pool_match']:
        sl = slugify(j['company'])
        if sl and sl in sitemap: j['yc_slug'] = sl
        elif sl and sl.replace('-','') in {s.replace('-','') for s in sitemap}: j['yc_slug'] = ''
        if j.get('yc_slug'): new_cos.append(j)

# --- reverse founder lookup for new YC companies (capped) ---
from yc_parse import extract_company, slim
import dns.resolver
res = dns.resolver.Resolver(); res.lifetime = 6
def band(n):
    if n is None: return ''
    if 11 <= n <= 50: return '11-50'
    if 51 <= n <= 200: return '51-200'
    if 201 <= n <= 500: return '201-500'
    return ''
candidates, done_slugs = [], set()
for j in new_cos:
    sl = j['yc_slug']
    if sl in done_slugs or len(done_slugs) >= 15: continue
    done_slugs.add(sl)
    try:
        obj = extract_company(f'https://www.ycombinator.com/companies/{sl}')
        if not obj: continue
        d = slim(obj)
        if (d.get('ycdc_status') or '').lower() != 'active': continue
        b = band(d.get('team_size'))
        fs = [f for f in (d.get('founders') or []) if f.get('is_active') and re.search(r'(founder|ceo|managing director)', (f.get('title') or ''), re.I)]
        if not fs: continue
        f = fs[0]
        w = d.get('website') or ''
        dom = re.sub(r'^https?://', '', w).split('/')[0]; dom = re.sub(r'^www\.', '', dom)
        parts_ = dom.split('.')
        if len(parts_) >= 3 and '.'.join(parts_[-2:]) in {'co.uk','com.au','co.in','com.br','com.mx','co.il'}: dom = '.'.join(parts_[-3:])
        elif len(parts_) >= 2: dom = '.'.join(parts_[-2:])
        has_mx = False
        try: has_mx = bool(res.resolve(dom, 'MX'))
        except Exception: pass
        fn = f.get('full_name') or ''
        toks = [t for t in re.sub(r'[^\w\s]', ' ', fn).split() if len(t) > 1]
        first = toks[0].lower() if toks else ''; last = toks[-1].lower() if len(toks) > 1 else ''
        email = ''
        if has_mx and first and last:
            email = (f'{first}@{dom}' if (d.get('team_size') or 0) <= 50 else f'{first}.{last}@{dom}')
        candidates.append({'company': d.get('name'), 'yc_slug': sl, 'yc_page': f'https://www.ycombinator.com/companies/{sl}',
            'founder': fn, 'founder_title': f.get('title'), 'band': b, 'team_size': d.get('team_size'),
            'country': d.get('country'), 'city': d.get('city'), 'website': w, 'domain': dom, 'mx': has_mx,
            'open_role': j['title'], 'job_url': j['url'], 'feed_source': j['source'],
            'email_INFERRED_UNVERIFIED': email, 'industry': ', '.join(d.get('tags') or [])})
        time.sleep(0.5)
    except Exception as e:
        print('yc lookup err', sl, str(e)[:80])

import csv
os.makedirs('leadgen/results', exist_ok=True)
with open('leadgen/results/cos_job_feed.csv', 'w', newline='', encoding='utf-8-sig') as f:
    w = csv.DictWriter(f, fieldnames=['level','source','company','title','url','location','email_in_posting','pool_match','extra'])
    w.writeheader(); w.writerows(feeds_out)
with open('leadgen/results/new_p0_candidates.csv', 'w', newline='', encoding='utf-8-sig') as f:
    cols = ['company','founder','founder_title','band','country','city','open_role','job_url','feed_source','website','domain','email_INFERRED_UNVERIFIED','mx','yc_page','industry']
    w = csv.DictWriter(f, fieldnames=cols, extrasaction='ignore'); w.writeheader(); w.writerows(candidates)

print(f'FEED DONE | jobs flagged: {len(feeds_out)} (HOT {sum(1 for j in feeds_out if j["level"]=="HOT")}, WARM {sum(1 for j in feeds_out if j["level"]=="WARM")}) | pool matches: {sum(1 for j in feeds_out if j.get("pool_match"))} | new YC candidates: {len(candidates)}')
if errors: print('errors:', errors)
for j in feeds_out[:25]:
    if j['level'] == 'HOT': print(' HOT:', j['company'][:28], '|', j['title'][:50], '|', j['url'][:60])
