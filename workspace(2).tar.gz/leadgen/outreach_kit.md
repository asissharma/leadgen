# OUTREACH KIT — Chief of Staff / Founder's Office Job Campaign
Built 2026-10-01 · pairs with `results/contacts_enriched.xlsx` (Action Plan tab) and `results/hot_targets.csv`

**The edge:** 99% of job seekers spray resumes and wait. You will only contact founders where a **hiring signal exists**, apply through the front door *and* the founder's inbox simultaneously, and lead with **proof of work** instead of a CV. Nobody at your target level does all three.

---

## 1. Priority tiers (from the radar, 2026-10-01)

| Tier | Who | Move | Timing |
|---|---|---|---|
| **P0** (8) | Founder is a hiring decision-maker AND the company has a live CoS/Founder's-Office/BizOps/EA-to-founders req | Dual-track: formal application + founder email referencing the exact req | **48h** |
| **P1** (8) | Company is hiring ops/strategy roles but has no CoS req | "Create-the-role" pitch to founder | week 1 |
| **P2** (41) | Has open reqs (growing) but nothing matching | LinkedIn warm-up + re-scan weekly; strike when a matching req appears | rolling |
| **P3** (47) | No signal | Monitor only (radar re-run monthly) | — |

P0 right now: **Vapi (Chief of Staff), Verse Medical (Chief of Staff), Encord (Founder's Office), Zip (BizOps Mgr), Gigs (Head of Ops/BizOps), Stepful (EA to Founders), Twenty (StratFin&BizOps), Jeeves (S&O Analyst)**. Apply URLs are in `hot_targets.csv`.

## 2. P0 dual-track playbook (per company, ~45 min each)

**Step 1 — Front door (30 min):** Read the live req (URL in hot_targets.csv). Mirror its exact language into your resume headline + 3 bullets. Apply.

**Step 2 — Proof of work (15 min):** Build ONE page: *"What I'd own in the first 90 days at [COMPANY]"* — see §6. This is the attachment/hook that gets founders to reply.

**Step 3 — Founder email (same day as apply).** Template:

> **Subject:** Your [ROLE] req — 90-day plan inside
>
> Hi [FIRST_NAME],
>
> Saw [COMPANY] is hiring a [ROLE] and applied through your careers page — flagging it here too because the standard funnel buries people.
>
> [PROOF_LINE — one sentence tying a real, verifiable thing about them to you: e.g. "You're scaling [X] after [Series A / YC W21 / the launch of Y] — that's exactly the stage where the founder's calendar, ops stack, and follow-through start breaking."]
>
> I attached a one-page 90-day plan for the role: what I'd own in weeks 1–4 / 5–8 / 9–12, including [SPECIFIC_ITEM pulled from their req].
>
> If it's directionally right, 15 minutes this week? If not, no follow-ups from me — just tell me who else on your team owns this hire.
>
> [YOUR_NAME] · [CITY/TZ] · [PHONE] · [LINKEDIN_URL]

Rules: ≤130 words · send Tue–Thu 7–9am **their** timezone · plain text, 1 attachment max (PDF one-pager) · never "I am writing to express".

**Step 4 — Cadence (max 5 touches, then stop forever):**
- **D0:** apply + founder email
- **D0/D1:** LinkedIn connection request (no pitch): *"Hi [FIRST_NAME] — applied for the [ROLE] role and sent you a 90-day plan. Would value having you in my network either way."* (≤300 chars)
- **D3:** email bump, 2 lines: *"Floating this back up — happy to also share [SPECIFIC_ARTIFACT: e.g. 'the ops-audit checklist I'd run in week 1']."*
- **D5 (if connected):** LinkedIn message with the one-pager inline as text (not attachment).
- **D7 (if phone in list & business line):** call. Script §5.
- **D10:** break-up email: *"Closing the loop — I'll assume the timing's off. If the role reopens or a Founder's Office need shows up later, my door's open. Withdrawing my application so your pipeline stays clean."* (Break-ups get replies; withdrawing the app is a power move only if you mean it — otherwise say "keeping my app in, but won't email again.")
- Any "no/not interested" → `results/suppression_list.csv` same day.

## 3. P1 create-the-role pitch (ops-hiring companies)

> **Subject:** You're hiring ops — consider one step up the stack
>
> Hi [FIRST_NAME], noticed [COMPANY] is hiring [WARM_ROLE from radar] (and [N] other roles). Growth like that usually lands the same problem on the founder: cross-team follow-through, meeting/prep load, and special projects with no owner.
>
> That's a Chief of Staff / Founder's Office function — cheaper than the [WARM_ROLE]'s first-year ramp going sideways, and it compounds. One-pager attached on what I'd own in 90 days.
>
> Worth 15 minutes, or should I talk to whoever runs ops for you?

## 4. One-pager structure (§6 detail)
Header (name, one-line positioning: "Chief of Staff — I make founders' priorities survive contact with the org") → 3 quantified wins → **The 90-day plan for THIS company** (Weeks 1–4: audit — shadow founder 2 days, map all open loops/commitments, stand up weekly ops cadence; Weeks 5–8: own — take over inbox triage, board/investor prep, cross-team OKR tracking; Weeks 9–12: compound — kill 1 meeting series, ship 1 founder-proxy decision framework, run 1 special project end-to-end) → ask (15 min).

## 5. Call script (main lines — 23 in the list)
- **Gatekeeper:** *"Hi — [YOUR_NAME], calling about the [ROLE] position I applied for. I sent [FOUNDER] a 90-day plan and wanted to make sure it didn't get lost. Is there an email or assistant I should route it through?"* (Goal: name/email of EA or hiring manager, not the founder.)
- **Founder voicemail (≤20s):** *"[FOUNDER], [YOUR_NAME] — applied for [ROLE], sent you a one-page 90-day plan Tuesday. Not calling to chase; if the plan's off-base, one sentence back tells me more than silence. [PHONE]."*
- **Compliance:** business lines only, business hours their TZ, identify yourself, no repeated calls after a no (TCPA/DNC).

## 6. Personalization ammo (all in your spreadsheet)
Per row you already have: founder name/title, YC batch (Notes), headcount band, open-role signal + URL (Notes/Hiring Signals tab), industry tags, LinkedIn (17 personal + 85 company), compliance flag. Before each send, 10-minute ritual: read the req → check company LinkedIn last 5 posts → check founder's last post if personal URL exists → write the PROOF_LINE from what you saw. Never send without a PROOF_LINE that couldn't apply to another company.

## 7. Volume, tracking, iteration
- **Cap:** ≤10 new P0/P1 emails/day from personal Gmail (warm-up matters more than volume). LinkedIn: ≤15 connection requests/day.
- **Track** in the Action Plan tab: Stage (`To-contact → Applied+Emailed → Bumped → Replied → Call → Interview / Dead`), Date sent, Follow-up, Reply?.
- **Benchmarks:** reply ≥20% = keep copy; 10–20% = sharpen PROOF_LINE; <10% after 30 sends = rework positioning (one-pager, not templates). Meetings/replies ≥3 per 10 P0 dual-tracks is a strong funnel.
- **Weekly loop:** re-run radar (`09_hiring_signals.py` + `10_action_plan.py`) — P2→P0 promotions appear as companies post reqs; re-run ZeroBounce when credits reset (92 pending); check Apollo saved-search alerts; first Tuesday monthly: HN Who's Hiring re-scan.

## 8. Compliance (unchanged hard rules)
1:1 personalized job-application messages only; true identity + working reply address in every email; honor opt-outs instantly via `suppression_list.csv`; GDPR/UK rows (19 flagged) get extra care — no bulk tooling, no tracking pixels; EU/UK/CA flags are in Notes. Dead emails (3, suppressed) must never be re-added.
